$(function () {
    const $navigation = $("#mainNavigation");
    const $applicationStatusPill = $("#applicationStatusPill");
    const $applicationStatusText = $("#applicationStatusText");
    const $askForm = $("#askForm");
    const $questionInput = $("#questionInput");
    const $askButton = $("#askButton");
    const $previewSourcesButton = $("#previewSourcesButton");
    const $clearButton = $("#clearQuestionButton");
    const $resetChatSettings = $("#resetChatSettings");
    const $chatModel = $("#chatModel");
    const $chatRetrievalMethod = $("#chatRetrievalMethod");
    const $chatTopK = $("#chatTopK");
    const $chatTemperature = $("#chatTemperature");
    const $chatTopP = $("#chatTopP");
    const $chatSettingsControls = $chatModel.add($chatRetrievalMethod).add($chatTopK).add($chatTemperature).add($chatTopP);
    const $chatSettingsSummary = $("#chatSettingsSummary");
    const $suggestionButtons = $(".suggestion-button");
    const $emptyState = $("#answerEmptyState");
    const $loadingState = $("#answerLoadingState");
    const $loadingText = $("#answerLoadingText");
    const $errorState = $("#answerErrorState");
    const $answerResult = $("#answerResult");
    const $answerResultLabel = $("#answerResultLabel");
    const $answerText = $("#answerText");
    const $answerMeta = $("#answerMeta");
    const $sourceList = $("#sourceList");
    const $conversationThread = $("#conversationThread");
    const $conversationStatus = $("#conversationStatus");
    const $conversationTurns = $("#conversationTurns");
    const $newConversationButton = $("#newConversationButton");
    // Conversation memory: the server stores every turn; the page only keeps
    // the active thread id and the completed turns it has displayed.
    let conversationId = null;
    let conversationTurns = [];
    // True when the newest turn is displayed in the answer panel (just answered);
    // false after reopening a saved chat, where every turn is listed in the thread.
    let latestTurnInAnswerPanel = true;

    // Accounts: the signed-in user owns their conversations. Every request to the
    // server carries the session's CSRF token.
    const $accountSignedOut = $("#accountSignedOut");
    const $accountSignedIn = $("#accountSignedIn");
    const $accountForm = $("#accountForm");
    const $accountUsername = $("#accountUsername");
    const $accountPassword = $("#accountPassword");
    const $accountDisplayName = $("#accountDisplayName");
    const $accountDisplayNameField = $("#accountDisplayNameField");
    const $accountPasswordHint = $("#accountPasswordHint");
    const $accountError = $("#accountError");
    const $accountSubmitButton = $("#accountSubmitButton");
    const $signInModeButton = $("#signInModeButton");
    const $registerModeButton = $("#registerModeButton");
    const $accountDisplayNameLabel = $("#accountDisplayNameLabel");
    const $signOutButton = $("#signOutButton");
    const $refreshChatsButton = $("#refreshChatsButton");
    const $recentChatList = $("#recentChatList");
    const $recentChatsEmpty = $("#recentChatsEmpty");
    let currentUser = null;
    let csrfToken = "";
    let accountMode = "login";
    let registrationAllowed = true;

    $.ajaxSetup({
        beforeSend: function (xhr) {
            if (csrfToken) {
                xhr.setRequestHeader("X-CSRF-Token", csrfToken);
            }
        },
    });
    const $documentForm = $("#documentUploadForm");
    const $documentFile = $("#documentFile");
    const $documentTitle = $("#documentTitle");
    const $documentCategory = $("#documentCategory");
    const $replaceDocumentId = $("#replaceDocumentId");
    const $cancelReplaceButton = $("#cancelReplaceButton");
    const $uploadDocumentButton = $("#uploadDocumentButton");
    const $uploadSelection = $("#uploadSelection");
    const $duplicateDocumentPrompt = $("#duplicateDocumentPrompt");
    const $duplicateDocumentName = $("#duplicateDocumentName");
    const $confirmDuplicateReplacement = $("#confirmDuplicateReplacement");
    const $cancelDuplicateUpload = $("#cancelDuplicateUpload");
    const $documentMessage = $("#documentMessage");
    const $documentList = $("#documentList");
    const $refreshDocumentsButton = $("#refreshDocumentsButton");
    const $restoreBundledDocumentsButton = $("#restoreBundledDocumentsButton");
    const $deleteAllDocumentsButton = $("#deleteAllDocumentsButton");
    const $documentSearch = $("#documentSearch");
    const $documentCategoryFilter = $("#documentCategoryFilter");
    const $documentTypeFilter = $("#documentTypeFilter");
    const $documentSort = $("#documentSort");
    const $documentVisibleCount = $("#documentVisibleCount");
    const $documentCount = $("#documentCount");
    const $categoryCount = $("#categoryCount");
    const $overviewChunkCount = $("#overviewChunkCount");
    const $evaluationQuestionCount = $("#evaluationQuestionCount");
    const $evaluationDatasetSummary = $("#evaluationDatasetSummary");
    const $evaluationDatasetSelect = $("#evaluationDatasetSelect");
    const $evaluationQuestionList = $("#evaluationQuestionList");
    const $evaluationCategoryFilter = $("#evaluationCategoryFilter");
    const $evaluationStatusFilter = $("#evaluationStatusFilter");
    const $experimentDatasetCount = $("#experimentDatasetCount");
    const $experimentRunCount = $("#experimentRunCount");
    const $experimentRunCountNote = $("#experimentRunCountNote");
    const $evaluatorCount = $("#evaluatorCount");
    const $overviewEvaluatorCount = $("#overviewEvaluatorCount");
    const $experimentHumanReviewCount = $("#experimentHumanReviewCount");
    const $researchReadinessList = $("#researchReadinessList");
    const $evaluatorSummary = $("#evaluatorSummary");
    const $evaluatorGoalSelect = $("#evaluatorGoalSelect");
    const $evaluatorGoalPrimary = $("#evaluatorGoalPrimary");
    const $evaluatorGoalSecondary = $("#evaluatorGoalSecondary");
    const $evaluatorGoalCaution = $("#evaluatorGoalCaution");
    const $evaluatorGoalReference = $("#evaluatorGoalReference");
    const $standaloneResponseList = $("#standaloneResponseList");
    const $evaluationRunList = $("#evaluationRunList");
    const $evaluationResultDetail = $("#evaluationResultDetail");
    const $evaluationLists = $standaloneResponseList.add($evaluationRunList);
    const $newTestRunToggle = $("#newTestRunToggle");
    const $newTestRunForm = $("#newTestRunForm");
    const $closeNewTestRun = $("#closeNewTestRun");
    const $newTestDatasetId = $("#newTestDatasetId");
    const $newTestExperimentMode = $("#newTestExperimentMode");
    const $newTestBaselineField = $("#newTestBaselineField");
    const $newTestBaselineRun = $("#newTestBaselineRun");
    const $newTestExperimentField = $("#newTestExperimentField");
    const $newTestExperimentKey = $("#newTestExperimentKey");
    const $newTestChangeField = $("#newTestChangeField");
    const $newTestControlledVariable = $("#newTestControlledVariable");
    const $newTestComparisonGuide = $("#newTestComparisonGuide");
    const $newTestBaselineSummary = $("#newTestBaselineSummary");
    const $newTestName = $("#newTestName");
    const $newTestLimit = $("#newTestLimit");
    const $newTestQuestionIds = $("#newTestQuestionIds");
    const $newTestModel = $("#newTestModel");
    const $newTestRetrieval = $("#newTestRetrieval");
    const $newTestTopK = $("#newTestTopK");
    const $newTestTemperature = $("#newTestTemperature");
    const $newTestTopP = $("#newTestTopP");
    const $newTestCorpusScope = $("#newTestCorpusScope");
    const $newTestCategoryField = $("#newTestCategoryField");
    const $newTestCategoryChoices = $("#newTestCategoryChoices");
    const $previewNewTestRun = $("#previewNewTestRun");
    const $createNewTestRun = $("#createNewTestRun");
    const $newTestRunStatus = $("#newTestRunStatus");
    const $findingBaselineCount = $("#findingBaselineCount");
    const $findingAdvancedCount = $("#findingAdvancedCount");
    const $findingHumanCount = $("#findingHumanCount");
    const $findingRules = $("#findingRules");
    const $findingMatchedComparisons = $("#findingMatchedComparisons");
    const $findingRunComparison = $("#findingRunComparison");
    const $findingMetricCatalog = $("#findingMetricCatalog");
    const generationEnabled = $askForm.data("generationEnabled") === true;
    let evaluationQuestions = [];
    let evaluationDatasetQuestionCount = 0;
    let evaluationRuns = [];
    let evaluatorCatalog = [];
    let dashboardEvaluatorCatalog = [];

    function refreshDashboardEvaluatorCatalog() {
        const methods = new Map();

        evaluatorCatalog.forEach(function (evaluator) {
            const key = String(evaluator.evaluator_key || "");
            if (!key) {
                return;
            }

            const existing = methods.get(key);
            if (!existing) {
                methods.set(key, evaluator);
                return;
            }

            const versionParts = function (value) {
                return String(value || "0").split(".").map(function (part) {
                    return Number(part) || 0;
                });
            };

            const currentParts = versionParts(evaluator.version);
            const existingParts = versionParts(existing.version);

            for (let i = 0; i < Math.max(currentParts.length, existingParts.length); i++) {
                const difference = (currentParts[i] || 0) - (existingParts[i] || 0);
                if (difference > 0) {
                    methods.set(key, evaluator);
                    break;
                }
                if (difference < 0) {
                    break;
                }
            }
        });

        dashboardEvaluatorCatalog = Array.from(methods.values());
    }

    let currentEvaluationResponseId = null;
    let evaluationResponseContexts = new Map();
    let indexedDocuments = [];
    let requestedNewTestCategories = [];
    let pendingDuplicateDocument = null;
    let documentListRequest = null;
    let ingestionStartedAt = null;
    let ingestionTimer = null;

    const $workspaceViews = $("[data-view-panel]");

    function loadApplicationHealth() {
        function showUnavailable(message) {
            $applicationStatusPill.removeClass("live-pill muted").addClass("unavailable-pill");
            $applicationStatusText.text("Application data unavailable");
            $applicationStatusPill.attr("title", message);
        }
        $.ajax({
            url: "api/health.php",
            method: "GET",
            dataType: "json",
            timeout: 10000,
        })
            .done(function (response) {
                if (response?.ok !== true || response.data?.status !== "ready") {
                    showUnavailable("Application readiness could not be confirmed. Try again or contact the application administrator.");
                    return;
                }
                $applicationStatusPill.removeClass("muted unavailable-pill").addClass("live-pill");
                $applicationStatusText.text("Application data ready");
                $applicationStatusPill.removeAttr("title");
            })
            .fail(function (xhr) {
                const message = xhr.responseJSON?.error ||
                    "Application data is temporarily unavailable. Try again or contact the application administrator.";
                showUnavailable(message);
            });
    }

    function preferredScrollBehavior() {
        return window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth";
    }

    function activateWorkspaceView(viewName, updateHistory, focusHeading) {
        const normalizedView = $workspaceViews.filter('[data-view-panel="' + viewName + '"]').length
            ? viewName
            : "overview";
        $workspaceViews.each(function () {
            $(this).prop("hidden", $(this).data("viewPanel") !== normalizedView);
        });
        const navigationView = normalizedView === "report" ? "results" : normalizedView;
        $navigation.find("[data-view]").each(function () {
            const isActive = $(this).data("view") === navigationView;
            $(this).toggleClass("active", isActive).attr("aria-current", isActive ? "page" : null);
        });
        if (updateHistory) {
            window.history.pushState({ view: normalizedView }, "", "#" + normalizedView);
        }
        window.scrollTo({ top: 0, behavior: preferredScrollBehavior() });
        if (focusHeading) {
            const $heading = $workspaceViews
                .filter('[data-view-panel="' + normalizedView + '"]')
                .find("h1, h2")
                .first();
            if ($heading.length) {
                $heading.attr("tabindex", "-1").trigger("focus");
            }
        }
    }

    $(document).on("click", 'a[href^="#"]', function (event) {
        const viewName = String($(this).attr("href") || "").slice(1);
        if ($workspaceViews.filter('[data-view-panel="' + viewName + '"]').length) {
            event.preventDefault();
            activateWorkspaceView(viewName, true, true);
        }
    });

    $(window).on("hashchange", function () {
        activateWorkspaceView(window.location.hash.slice(1), false);
    });

    $(window).on("popstate", function () {
        activateWorkspaceView(window.location.hash.slice(1), false);
    });

    function setBusy(isBusy) {
        $questionInput.prop("disabled", isBusy);
        $askButton.prop("disabled", isBusy || !generationEnabled || !currentUser);
        $clearButton.prop("disabled", isBusy);
        $previewSourcesButton.prop("disabled", isBusy);
        $resetChatSettings.prop("disabled", isBusy);
        $chatSettingsControls.prop("disabled", isBusy);
        $suggestionButtons.prop("disabled", isBusy);
        $newConversationButton.prop("disabled", isBusy);
    }

    function renderConversation() {
        // After an answer the newest turn is shown in the answer panel, so only
        // earlier turns are listed here. A reopened chat lists every turn.
        const earlierTurns = latestTurnInAnswerPanel ? conversationTurns.slice(0, -1) : conversationTurns;
        $conversationTurns.empty();
        earlierTurns.forEach(function (turn) {
            const $item = $("<li>").addClass("conversation-turn");
            $("<p>").addClass("conversation-question").text(turn.question).appendTo($item);
            $("<p>").addClass("conversation-answer").text(turn.answer).appendTo($item);
            $item.appendTo($conversationTurns);
        });
        const count = conversationTurns.length;
        $conversationStatus.text(
            "Conversation in progress · " + count + " question" + (count === 1 ? "" : "s")
        );
        $conversationThread.prop("hidden", conversationId === null);
        $recentChatList.find(".recent-chat").each(function () {
            $(this).toggleClass("active", Number($(this).data("conversationId")) === conversationId);
        });
    }

    function startNewConversation() {
        conversationId = null;
        conversationTurns = [];
        latestTurnInAnswerPanel = true;
        renderConversation();
    }

    function shortDate(value) {
        const date = new Date(String(value || "").replace(" ", "T"));
        if (Number.isNaN(date.getTime())) {
            return "";
        }
        return date.toLocaleDateString(undefined, { month: "short", day: "numeric" });
    }

    function renderRecentChats(conversations) {
        $recentChatList.empty();
        $recentChatsEmpty.prop("hidden", conversations.length > 0);
        conversations.forEach(function (chat) {
            const id = Number(chat.conversation_id);
            const count = Number(chat.question_count) || 0;
            const $item = $("<li>").addClass("recent-chat").attr("data-conversation-id", id);
            const $open = $("<button>")
                .addClass("recent-chat-open")
                .attr("type", "button")
                .attr("data-conversation-id", id);
            $("<strong>").text(chat.title || "Untitled chat").appendTo($open);
            $("<span>")
                .text(count + " question" + (count === 1 ? "" : "s") + " · " + shortDate(chat.updated_at))
                .appendTo($open);
            const $remove = $("<button>")
                .addClass("recent-chat-remove")
                .attr("type", "button")
                .attr("data-conversation-id", id)
                .attr("aria-label", "Remove " + (chat.title || "chat") + " from recent chats")
                .text("Remove");
            $item.append($open, $remove).appendTo($recentChatList);
        });
        renderConversation();
    }

    function loadRecentChats() {
        if (!currentUser) {
            renderRecentChats([]);
            return;
        }
        $.ajax({ url: "api/conversations.php", method: "GET", dataType: "json" })
            .done(function (response) {
                renderRecentChats(response?.data?.conversations || []);
            })
            .fail(function (xhr) {
                if (xhr.status === 401) {
                    applySession({ user: null, csrf_token: csrfToken });
                }
            });
    }

    function openConversation(id) {
        if (!currentUser) {
            return;
        }
        $.ajax({
            url: "api/conversations.php",
            method: "GET",
            dataType: "json",
            data: { conversation_id: id },
        })
            .done(function (response) {
                const messages = response?.data?.messages || [];
                const turns = [];
                messages.forEach(function (message) {
                    if (message.role === "user") {
                        turns.push({ question: message.content, answer: "" });
                    } else if (turns.length) {
                        turns[turns.length - 1].answer = message.content;
                    }
                });
                conversationId = Number(response.data.conversation.conversation_id);
                conversationTurns = turns;
                latestTurnInAnswerPanel = false;
                resetAnswer();
                renderConversation();
                $questionInput.val("").trigger("focus");
            })
            .fail(function (xhr) {
                if (xhr.responseJSON?.conversation_reset) {
                    startNewConversation();
                    loadRecentChats();
                }
                showError(xhr.responseJSON?.error || "That chat could not be opened. Try again.");
            });
    }

    function setAccountMode(mode) {
        accountMode = mode === "register" && registrationAllowed ? "register" : "login";
        const registering = accountMode === "register";
        $signInModeButton.toggleClass("active", !registering).attr("aria-pressed", String(!registering));
        $registerModeButton.toggleClass("active", registering).attr("aria-pressed", String(registering));
        $registerModeButton.prop("hidden", !registrationAllowed);
        $accountDisplayNameField.prop("hidden", !registering);
        $accountPasswordHint.prop("hidden", !registering);
        $accountPassword.attr("autocomplete", registering ? "new-password" : "current-password");
        $accountSubmitButton.text(registering ? "Create account" : "Sign in");
        $accountError.prop("hidden", true).text("");
    }

    function applySession(session) {
        const previousUser = currentUser ? currentUser.username : null;
        currentUser = session.user || null;
        if (session.csrf_token) {
            csrfToken = String(session.csrf_token);
        }
        if (typeof session.registration_allowed === "boolean") {
            registrationAllowed = session.registration_allowed;
        }
        $accountSignedOut.prop("hidden", currentUser !== null);
        $accountSignedIn.prop("hidden", currentUser === null);
        $accountDisplayNameLabel.text(currentUser ? currentUser.display_name : "");
        if ((currentUser ? currentUser.username : null) !== previousUser) {
            // Never carry one person's chat into another person's session.
            startNewConversation();
            resetAnswer();
        }
        setAccountMode(accountMode);
        setBusy(false);
        loadRecentChats();
    }

    function loadSession() {
        $.ajax({ url: "api/auth.php", method: "GET", dataType: "json" })
            .done(applySession)
            .fail(function () {
                applySession({ user: null });
            });
    }

    $signInModeButton.on("click", function () { setAccountMode("login"); });
    $registerModeButton.on("click", function () { setAccountMode("register"); });

    $accountForm.on("submit", function (event) {
        event.preventDefault();
        const username = String($accountUsername.val() || "").trim();
        const password = String($accountPassword.val() || "");
        if (!username || !password) {
            $accountError.prop("hidden", false).text("Enter your username and password.");
            return;
        }
        $accountSubmitButton.prop("disabled", true);
        $.ajax({
            url: "api/auth.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({
                action: accountMode,
                username: username,
                password: password,
                display_name: String($accountDisplayName.val() || "").trim(),
            }),
        })
            .done(function (session) {
                $accountPassword.val("");
                $accountDisplayName.val("");
                accountMode = "login";
                applySession(session);
            })
            .fail(function (xhr) {
                $accountError
                    .prop("hidden", false)
                    .text(xhr.responseJSON?.error || "You could not be signed in. Try again.");
            })
            .always(function () {
                $accountSubmitButton.prop("disabled", false);
            });
    });

    $signOutButton.on("click", function () {
        $.ajax({
            url: "api/auth.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ action: "logout" }),
        }).always(function (session) {
            applySession(session && session.ok ? session : { user: null });
        });
    });

    $refreshChatsButton.on("click", loadRecentChats);

    $recentChatList.on("click", ".recent-chat-open", function () {
        openConversation(Number($(this).data("conversationId")));
    });

    $recentChatList.on("click", ".recent-chat-remove", function () {
        const id = Number($(this).data("conversationId"));
        $.ajax({
            url: "api/conversations.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ action: "archive", conversation_id: id }),
        }).always(function () {
            if (id === conversationId) {
                startNewConversation();
                resetAnswer();
            }
            loadRecentChats();
        });
    });

    function showLoading(previewOnly) {
        $emptyState.prop("hidden", true);
        $errorState.prop("hidden", true).text("");
        $answerResult.prop("hidden", true);
        $loadingState.prop("hidden", false);
        $loadingText.text(previewOnly
            ? "Retrieving the sources these settings would use..."
            : "Retrieving sources and generating an answer...");
        setBusy(true);
    }

    function showError(message) {
        $emptyState.prop("hidden", true);
        $loadingState.prop("hidden", true);
        $answerResult.prop("hidden", true);
        $errorState.prop("hidden", false).text(message);
    }

    function resetAnswer() {
        $loadingState.prop("hidden", true);
        $errorState.prop("hidden", true).text("");
        $answerResult.prop("hidden", true);
        $emptyState.prop("hidden", false);
        $answerText.text("");
        $answerMeta.empty();
        $sourceList.empty();
    }

    function addMeta(label, value) {
        $("<span>")
            .append($("<strong>").text(label + ": "))
            .append(document.createTextNode(value))
            .appendTo($answerMeta);
    }

    function renderSources(sources) {
        $sourceList.empty();

        if (!Array.isArray(sources) || sources.length === 0) {
            $("<p>")
                .addClass("text-muted mb-0")
                .text("No sources were returned.")
                .appendTo($sourceList);
            return;
        }

        sources.forEach(function (source, index) {
            const distance = Number(source.distance);
            const finalScore = Number(source.retrieval_score);
            const scoreParts = [];

            if (source.distance !== null &&
                source.distance !== undefined &&
                Number.isFinite(distance)) {
                scoreParts.push("distance " + distance.toFixed(6));
            }

            if (source.keyword_score !== null &&
                source.keyword_score !== undefined) {
                scoreParts.push(
                    "lexical " + compactNumber(source.keyword_score, 3)
                );
            }

            if (source.retrieval_score !== null &&
                source.retrieval_score !== undefined &&
                Number.isFinite(finalScore)) {
                scoreParts.push("final " + finalScore.toFixed(6));
            }

            // Prefer the original filename retrieved from MySQL.
            const filename = source.original_filename ||
                source.source_path ||
                "Unknown document";

            // Normalize the extracted content type.
            const contentType = String(
                source.content_type || "text"
            ).replace(/_/g, " ");

            const formattedType = contentType
                .replace(/\b\w/g, function (character) {
                    return character.toUpperCase();
                });

            // Use the document extension to label the source location.
            const extension = filename.split(".").pop().toLowerCase();

            let locationLabel = "Page";
            if (extension === "pptx") {
                locationLabel = "Slide";
            }

            const metadata = [];

            if (source.page_number !== null &&
                source.page_number !== undefined) {
                metadata.push(locationLabel + " " + source.page_number);
            }

            if (source.chunk_index !== null &&
                source.chunk_index !== undefined) {
                metadata.push("Chunk " + source.chunk_index);
            }

            metadata.push("Type: " + formattedType);

            if (scoreParts.length > 0) {
                metadata.push(scoreParts.join(" · "));
            }

            // Create the source card.
            const $card = $("<article>").addClass("source-card");
            const $heading = $("<div>").addClass("source-heading");

            $("<strong>")
                .text((source.rank ?? index + 1) + ". " + filename)
                .appendTo($heading);

            $("<span>")
                .text(metadata.join(" · "))
                .appendTo($heading);

            $heading.appendTo($card);

            // Display the extracted evidence.
            $("<p>")
                .text(source.text || "No extracted text available.")
                .appendTo($card);

            $card.appendTo($sourceList);
        });
    }

    function showAnswer(result, previewOnly) {
        $loadingState.prop("hidden", true);
        $emptyState.prop("hidden", true);
        $errorState.prop("hidden", true).text("");
        $answerResult.prop("hidden", false);

        $answerResultLabel.text(previewOnly ? "Source preview" : "Grounded answer");
        $answerText.text(previewOnly
            ? "No model was called. These are the source chunks the selected retrieval settings would send to the model."
            : (result.answer || "No answer was returned."));
        $answerMeta.empty();
        if (!previewOnly) {
            addMeta("Model", modelDisplayName(result.model));
        }
        addMeta("Retrieval", retrievalDisplayName(result.retrieval_method));
        addMeta("Sources retrieved", String(result.top_k ?? "unknown"));
        if (Number(result.history_messages_used) > 0) {
            addMeta("Earlier messages used", String(result.history_messages_used));
        }
        if (result.retrieval_query && result.retrieval_query !== result.question) {
            addMeta("Searched for", result.retrieval_query);
        }
        if (!previewOnly) {
            addMeta("Latency", String(result.latency_ms ?? "unknown") + " ms");
        }
        if (result.persistence_error) {
            addMeta("Storage warning", result.persistence_error);
        }

        renderSources(result.sources);
    }

    function chatConfiguration() {
        return {
            model: String($chatModel.val()),
            retrieval_method: String($chatRetrievalMethod.val()),
            top_k: Number($chatTopK.val()),
            temperature: Number($chatTemperature.val()),
            top_p: Number($chatTopP.val()),
        };
    }

    function updateChatSettingsSummary() {
        const configuration = chatConfiguration();
        const usesDefaults = $chatSettingsControls.toArray().every(function (control) {
            return String($(control).val()) === String($(control).data("default"));
        });
        $chatSettingsSummary.text(
            (usesDefaults ? "Using recommended setup: " : "Using custom setup: ") +
            modelDisplayName(configuration.model) + " · " +
            retrievalDisplayName(configuration.retrieval_method) + " · " +
            configuration.top_k + " source" + (configuration.top_k === 1 ? "" : "s")
        );
    }

    function requestChat(action) {
        const question = $questionInput.val().trim();

        if (!question) {
            showError("Enter a question before submitting.");
            $questionInput.trigger("focus");
            return;
        }

        const previewOnly = action === "preview";
        const configuration = chatConfiguration();
        showLoading(previewOnly);
        $.ajax({
            url: "api/ask.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({
                question: question,
                action: action,
                model: configuration.model,
                retrieval_method: configuration.retrieval_method,
                top_k: configuration.top_k,
                temperature: configuration.temperature,
                top_p: configuration.top_p,
                conversation_id: conversationId,
            }),
        })
            .done(function (response) {
                if (!response || response.ok !== true || !response.data) {
                    showError("The server returned an incomplete answer.");
                    return;
                }
                showAnswer(response.data, previewOnly);
                if (!previewOnly && response.data.conversation_id) {
                    conversationId = Number(response.data.conversation_id);
                    conversationTurns.push({
                        question: response.data.question || question,
                        answer: response.data.answer || "",
                    });
                    latestTurnInAnswerPanel = true;
                    renderConversation();
                    $questionInput.val("");
                    loadRecentChats();
                }
            })
            .fail(function (xhr, status) {
                if (status === "abort") {
                    return;
                }
                if (xhr.responseJSON?.conversation_reset) {
                    startNewConversation();
                    loadRecentChats();
                }
                if (xhr.responseJSON?.sign_in_required) {
                    applySession({ user: null });
                    $accountUsername.trigger("focus");
                }
                const message = xhr.responseJSON?.error || "The answer could not be generated. Try again.";
                showError(message);
            })
            .always(function () {
                setBusy(false);
            });
    }

    $askForm.on("submit", function (event) {
        event.preventDefault();
        requestChat("answer");
    });

    $previewSourcesButton.on("click", function () {
        requestChat("preview");
    });

    $clearButton.on("click", function () {
        $questionInput.val("").prop("disabled", false).trigger("focus");
        setBusy(false);
        resetAnswer();
    });

    $newConversationButton.on("click", function () {
        startNewConversation();
        $questionInput.val("").prop("disabled", false).trigger("focus");
        setBusy(false);
        resetAnswer();
    });

    $resetChatSettings.on("click", function () {
        $chatSettingsControls.each(function () {
            $(this).val(String($(this).data("default")));
        });
        updateChatSettingsSummary();
    });

    $chatSettingsControls.on("change", updateChatSettingsSummary);
    updateChatSettingsSummary();
    setAccountMode("login");
    loadSession();

    $suggestionButtons.on("click", function () {
        $questionInput.val($(this).data("question")).trigger("focus");
    });

    $questionInput.on("keydown", function (event) {
        if (event.ctrlKey && event.key === "Enter") {
            $askForm.trigger("submit");
        }
    });

    function showDocumentMessage(message, type) {
        $documentMessage
            .removeClass("alert-success alert-danger alert-info")
            .addClass("alert-" + type)
            .text(message)
            .prop("hidden", false);
    }

    function resetReplacement() {
        $replaceDocumentId.val("");
        pendingDuplicateDocument = null;
        $cancelReplaceButton.prop("hidden", true);
        $duplicateDocumentPrompt.prop("hidden", true);
        $duplicateDocumentName.text("");
        $uploadDocumentButton.prop("disabled", false);
        $uploadDocumentButton.text("Upload and ingest");
        $uploadSelection.text("");
    }

    function selectReplacement(item) {
        $replaceDocumentId.val(item.document_id);
        pendingDuplicateDocument = null;
        $duplicateDocumentPrompt.prop("hidden", true);
        $duplicateDocumentName.text("");
        $documentTitle.val(item.title);
        $documentCategory.val(titleCaseLabel(item.category));
        $cancelReplaceButton.prop("hidden", false);
        $uploadDocumentButton.prop("disabled", false);
        $uploadDocumentButton.text("Replace and re-ingest");
        showDocumentMessage(
            "The new file will replace " + item.title + " after ingestion succeeds.",
            "info"
        );
    }

    function updateDocumentFilterOptions(documents) {
        const currentCategory = String($documentCategoryFilter.val() || "");
        const categories = [...new Set(documents.map(function (item) { return item.category; }))].sort();
        $documentCategoryFilter.find("option:not(:first)").remove();
        categories.forEach(function (category) {
            $documentCategoryFilter.append(
                $("<option>").val(category).text(titleCaseLabel(category))
            );
        });
        if (categories.includes(currentCategory)) {
            $documentCategoryFilter.val(currentCategory);
        }
        updateNewTestCategoryChoices(categories);
    }

    function updateNewTestCategoryChoices(categories) {
        const checkedValues = $newTestCategoryChoices.find("input:checked").map(function () {
            return String($(this).val());
        }).get();
        const selected = new Set(checkedValues.length ? checkedValues : requestedNewTestCategories);
        $newTestCategoryChoices.empty();
        if (!categories.length) {
            $newTestCategoryChoices.append($("<span>").text("No active source categories are available."));
            syncNewTestExperimentControls(false);
            return;
        }
        categories.forEach(function (category) {
            const checkboxId = "newTestCategory_" + String(category).replace(/[^a-z0-9_-]/gi, "_");
            const $checkbox = $("<input>").attr({
                id: checkboxId,
                type: "checkbox",
                value: category,
            }).addClass("form-check-input new-test-category-input");
            if (selected.has(String(category))) {
                $checkbox.prop("checked", true);
            }
            $newTestCategoryChoices.append(
                $("<label>").attr("for", checkboxId).append($checkbox, $("<span>").text(titleCaseLabel(category)))
            );
        });
        syncNewTestExperimentControls(false);
    }

    function selectedNewTestQuestionIds() {
        return $newTestQuestionIds.find("option:selected").map(function () {
            return Number($(this).val());
        }).get().filter(Number.isInteger);
    }

    function setSelectedNewTestQuestionIds(questionIds) {
        const selected = new Set((questionIds || []).map(Number));
        $newTestQuestionIds.find("option").each(function () {
            $(this).prop("selected", selected.has(Number($(this).val())));
        });
        $newTestLimit.val(String(selected.size));
    }

    function populateNewTestQuestionChoices() {
        const previouslySelected = selectedNewTestQuestionIds();
        const maxQuestions = Number($newTestLimit.data("max")) || 5;
        $newTestQuestionIds.empty();
        evaluationQuestions.forEach(function (question) {
            const number = Number(question.display_order) || Number(question.question_id);
            const label = "Question " + number + " · " + titleCaseLabel(question.category) + " · " + question.question_text;
            $newTestQuestionIds.append(
                $("<option>").val(question.question_id).text(label)
            );
        });
        if (previouslySelected.length) {
            setSelectedNewTestQuestionIds(previouslySelected.slice(0, maxQuestions));
            return;
        }
        const finalStudyNumbers = [1, 23, 35, 38, 46].slice(0, maxQuestions);
        const recommendedIds = evaluationQuestions.filter(function (question) {
            return finalStudyNumbers.includes(Number(question.display_order));
        }).map(function (question) {
            return Number(question.question_id);
        });
        setSelectedNewTestQuestionIds(
            recommendedIds.length === finalStudyNumbers.length
                ? recommendedIds
                : evaluationQuestions.slice(0, maxQuestions).map(function (question) {
                    return Number(question.question_id);
                })
        );
    }

    function documentRow(item) {
        const $row = $("<article>").addClass("list-item document-item");
        const $details = $("<div>").addClass("document-details");
        $("<strong>").text(item.title).appendTo($details);
        $("<span>")
            .text(item.original_filename + " · " + item.chunk_count + " chunks")
            .appendTo($details);
        if (item.ingestion_error) {
            $("<span>").addClass("text-danger").text(item.ingestion_error).appendTo($details);
        }
        $details.appendTo($row);

        const isUploaded = String(item.source_path).startsWith("storage/uploads/");
        const $actions = $("<div>").addClass("document-actions");
        $("<small>").text(
            String(item.source_type).toUpperCase() + " · " + item.status + " · " +
            (isUploaded ? "uploaded" : "bundled source")
        ).appendTo($actions);
        $("<button>")
            .addClass("btn btn-sm btn-outline-secondary replace-document-button")
            .attr("type", "button")
            .data("document", item)
            .text("Replace")
            .appendTo($actions);
        $("<button>")
            .addClass("btn btn-sm btn-outline-danger delete-document-button")
            .attr("type", "button")
            .data("document", item)
            .text("Delete")
            .appendTo($actions);
        $actions.appendTo($row);
        return $row;
    }

    function renderDocumentList() {
        $documentList.empty();
        const documentItems = indexedDocuments;
        const categories = new Set(documentItems.map(function (item) {
            return item.category;
        }));
        $documentCount.text(String(documentItems.length));
        $categoryCount.text(String(categories.size));
        $overviewChunkCount.text(String(documentItems.reduce(function (total, item) {
            return total + (Number(item.chunk_count) || 0);
        }, 0)));
        if (documentItems.length === 0) {
            $documentVisibleCount.text("0 indexed documents");
            $("<p>").addClass("text-muted").text("No indexed documents were found.").appendTo($documentList);
            return;
        }

        const query = String($documentSearch.val() || "").trim().toLowerCase();
        const category = String($documentCategoryFilter.val() || "");
        const type = String($documentTypeFilter.val() || "");
        const sort = String($documentSort.val() || "category");
        const visible = documentItems.filter(function (item) {
            const haystack = (item.title + " " + item.original_filename).toLowerCase();
            return (!query || haystack.includes(query)) &&
                (!category || item.category === category) &&
                (!type || item.source_type === type);
        });
        const comparators = {
            category: function (left, right) {
                return String(left.category).localeCompare(String(right.category)) ||
                    String(left.title).localeCompare(String(right.title));
            },
            name: function (left, right) { return String(left.title).localeCompare(String(right.title)); },
            newest: function (left, right) { return Number(right.document_id) - Number(left.document_id); },
            chunks: function (left, right) { return Number(right.chunk_count) - Number(left.chunk_count); },
        };
        visible.sort(comparators[sort] || comparators.category);
        $documentVisibleCount.text(
            visible.length + " of " + documentItems.length + " indexed document" +
            (documentItems.length === 1 ? "" : "s")
        );
        if (!visible.length) {
            $("<p>").addClass("text-muted").text("No documents match these filters.").appendTo($documentList);
            return;
        }

        if (sort === "category") {
            const grouped = new Map();
            visible.forEach(function (item) {
                if (!grouped.has(item.category)) {
                    grouped.set(item.category, []);
                }
                grouped.get(item.category).push(item);
            });
            grouped.forEach(function (items, groupName) {
                const $group = $("<section>").addClass("document-group");
                $group.append($("<div>").addClass("document-group-heading").append(
                    $("<strong>").text(titleCaseLabel(groupName)),
                    $("<span>").text(items.length + " document" + (items.length === 1 ? "" : "s"))
                ));
                const $stack = $("<div>").addClass("list-stack");
                items.forEach(function (item) { $stack.append(documentRow(item)); });
                $group.append($stack);
                $documentList.append($group);
            });
            return;
        }

        const $stack = $("<div>").addClass("list-stack");
        visible.forEach(function (item) { $stack.append(documentRow(item)); });
        $documentList.append($stack);
    }

    function loadDocuments() {
        if (documentListRequest) {
            return documentListRequest;
        }

        const hasRenderedDocuments = $documentList.find(".document-item").length > 0;
        if (!hasRenderedDocuments) {
            $documentList.html('<p class="text-muted">Loading indexed documents...</p>');
        }
        $refreshDocumentsButton.prop("disabled", true).text("Refreshing...");

        const delayedMessage = window.setTimeout(function () {
            if (!hasRenderedDocuments) {
                $documentList.html(
                    '<p class="text-muted">The local server is still working. ' +
                    "If a document is being ingested, this list will appear when it finishes.</p>"
                );
            }
        }, 4000);

        documentListRequest = $.ajax({
            url: "api/documents.php",
            method: "GET",
            dataType: "json",
            timeout: 130000,
        })
            .done(function (response) {
                if (response?.ok !== true) {
                    showDocumentMessage("The document list could not be loaded.", "danger");
                    return;
                }
                indexedDocuments = Array.isArray(response.data) ? response.data : [];
                updateDocumentFilterOptions(indexedDocuments);
                renderDocumentList();
            })
            .fail(function (xhr) {
                showDocumentMessage(xhr.responseJSON?.error || "The document list could not be loaded.", "danger");
                if (!hasRenderedDocuments) {
                    $documentList.html('<p class="text-danger">Document data is unavailable. Use Refresh to try again.</p>');
                }
            })
            .always(function () {
                window.clearTimeout(delayedMessage);
                documentListRequest = null;
                $refreshDocumentsButton.prop("disabled", false).text("Refresh");
            });

        return documentListRequest;
    }

    function startIngestionProgress() {
        ingestionStartedAt = Date.now();
        $refreshDocumentsButton.prop("disabled", true);
        ingestionTimer = window.setInterval(function () {
            const elapsedSeconds = Math.max(1, Math.floor((Date.now() - ingestionStartedAt) / 1000));
            showDocumentMessage(
                "Parsing, chunking, and embedding the document (" + elapsedSeconds + " seconds). " +
                "The first upload after startup can take longer.",
                "info"
            );
        }, 1000);
    }

    function stopIngestionProgress() {
        window.clearInterval(ingestionTimer);
        ingestionTimer = null;
        ingestionStartedAt = null;
    }

    $documentFile.on("change", function () {
        const file = this.files[0];
        if (!file) {
            $uploadSelection.text("");
            pendingDuplicateDocument = null;
            $duplicateDocumentPrompt.prop("hidden", true);
            if (!$replaceDocumentId.val()) {
                $uploadDocumentButton.prop("disabled", false);
            }
            return;
        }
        $uploadSelection.text(file.name + " · " + Math.ceil(file.size / 1024) + " KB");
        if (!$documentTitle.val().trim()) {
            $documentTitle.val(file.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " "));
        }
        const duplicate = indexedDocuments.find(function (item) {
            return String(item.original_filename).toLowerCase() === file.name.toLowerCase();
        });
        if (duplicate && !$replaceDocumentId.val()) {
            pendingDuplicateDocument = duplicate;
            $duplicateDocumentName.text(
                "A document named " + file.name + " already exists (" + duplicate.chunk_count + " chunks)."
            );
            $duplicateDocumentPrompt.prop("hidden", false);
            $uploadDocumentButton.prop("disabled", true);
            $documentMessage.prop("hidden", true).text("");
        } else {
            pendingDuplicateDocument = null;
            $duplicateDocumentPrompt.prop("hidden", true);
            $duplicateDocumentName.text("");
            $uploadDocumentButton.prop("disabled", false);
        }
    });

    $confirmDuplicateReplacement.on("click", function () {
        if (!pendingDuplicateDocument) {
            return;
        }
        selectReplacement(pendingDuplicateDocument);
    });

    $cancelDuplicateUpload.on("click", function () {
        $documentFile.val("");
        resetReplacement();
        $documentForm[0].reset();
        showDocumentMessage("Duplicate upload cancelled. The existing indexed document was not changed.", "info");
        $documentFile.trigger("focus");
    });

    $documentList.on("click", ".replace-document-button", function () {
        const item = $(this).data("document");
        selectReplacement(item);
        $documentFile.trigger("focus");
    });

    $documentList.on("click", ".delete-document-button", function () {
        const $button = $(this);
        const item = $button.data("document");
        const isUploaded = String(item.source_path).startsWith("storage/uploads/");
        const detail = isUploaded
            ? "Its uploaded file, live chunks, and embeddings will be removed."
            : "Its live chunks and embeddings will be removed; the bundled seed file will remain available for restoration.";
        if (!window.confirm("Delete " + item.title + " from the active index?\n\n" + detail)) {
            return;
        }

        $button.prop("disabled", true).text("Deleting...");
        showDocumentMessage("Removing the document and its indexed chunks...", "info");
        $.ajax({
            url: "api/documents.php",
            method: "DELETE",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ document_id: item.document_id }),
        })
            .done(function () {
                showDocumentMessage("Document deleted.", "success");
                resetAnswer();
                loadDocuments();
            })
            .fail(function (xhr) {
                showDocumentMessage(xhr.responseJSON?.error || "Document deletion failed.", "danger");
                $button.prop("disabled", false).text("Delete");
            });
    });

    $cancelReplaceButton.on("click", function () {
        resetReplacement();
        $documentForm[0].reset();
        $documentMessage.prop("hidden", true).text("");
    });

    $refreshDocumentsButton.on("click", function () {
        loadDocuments();
    });

    $restoreBundledDocumentsButton.on("click", function () {
        if (!window.confirm(
            "Restore and re-index the bundled Metro State source collection?\n\n" +
            "Bundled sources will be added or refreshed with the current index settings. Browser-uploaded documents will remain."
        )) {
            return;
        }
        $restoreBundledDocumentsButton.prop("disabled", true).text("Restoring…");
        $uploadDocumentButton.add($deleteAllDocumentsButton).prop("disabled", true);
        showDocumentMessage(
            "Restoring the bundled sources and rebuilding their searchable chunks. Keep this page open until the source list refreshes.",
            "info"
        );
        $.ajax({
            url: "api/documents.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            timeout: 310000,
            data: JSON.stringify({ action: "restore_bundled", confirmation: "RESTORE" }),
        })
            .done(function (response) {
                showDocumentMessage(
                    (response.data?.documents || 0) + " bundled documents restored with " +
                    (response.data?.chunks || 0) + " searchable chunks.",
                    "success"
                );
                resetAnswer();
                loadDocuments();
            })
            .fail(function (xhr) {
                showDocumentMessage(xhr.responseJSON?.error || "Bundled sources could not be restored.", "danger");
            })
            .always(function () {
                $restoreBundledDocumentsButton.prop("disabled", false).text("Restore bundled sources");
                $uploadDocumentButton.add($deleteAllDocumentsButton).prop("disabled", false);
            });
    });

    $documentSearch.on("input", renderDocumentList);
    $documentCategoryFilter.add($documentTypeFilter).add($documentSort).on("change", renderDocumentList);

    $deleteAllDocumentsButton.on("click", function () {
        if (!indexedDocuments.length) {
            showDocumentMessage("The active document index is already empty.", "info");
            return;
        }
        const confirmation = window.prompt(
            "This removes every document, live chunk, and embedding from the active index. " +
            "Bundled source files remain available for restoration. Type DELETE ALL to continue."
        );
        if (confirmation !== "DELETE ALL") {
            return;
        }
        $deleteAllDocumentsButton.prop("disabled", true).text("Deleting all…");
        showDocumentMessage("Clearing all documents, chunks, and embeddings from the active index…", "info");
        $.ajax({
            url: "api/documents.php",
            method: "DELETE",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ action: "delete_all", confirmation: confirmation }),
        })
            .done(function (response) {
                showDocumentMessage((response.data?.deleted_count || 0) + " documents removed from the active index.", "success");
                resetAnswer();
                loadDocuments();
            })
            .fail(function (xhr) {
                showDocumentMessage(xhr.responseJSON?.error || "The active index could not be cleared.", "danger");
            })
            .always(function () {
                $deleteAllDocumentsButton.prop("disabled", false).text("Delete all");
            });
    });

    $documentForm.on("submit", function (event) {
        event.preventDefault();
        if (pendingDuplicateDocument) {
            showDocumentMessage("Choose Replace existing or Cancel upload before continuing.", "info");
            $confirmDuplicateReplacement.trigger("focus");
            return;
        }
        const categoryKey = normalizeCategoryKey($documentCategory.val());
        if (categoryKey.length < 2 || categoryKey.length > 50) {
            showDocumentMessage("Enter a category with at least two letters or numbers.", "danger");
            $documentCategory.trigger("focus");
            return;
        }
        const formData = new FormData(this);
        formData.set("category", categoryKey);
        $uploadDocumentButton.prop("disabled", true).text("Parsing and ingesting...");
        $cancelReplaceButton.prop("disabled", true);
        showDocumentMessage(
            "Parsing, chunking, and embedding the document. Keep this page open; the indexed list will remain visible.",
            "info"
        );
        startIngestionProgress();

        $.ajax({
            url: "api/documents.php",
            method: "POST",
            data: formData,
            processData: false,
            contentType: false,
            dataType: "json",
        })
            .done(function (response) {
                const replacementText = Number(response.data.replaced_document_count)
                    ? " Previous same-name index record replaced."
                    : "";
                showDocumentMessage(
                    "Document ingested with " + response.data.chunk_count + " chunks." + replacementText,
                    "success"
                );
                resetAnswer();
                $documentForm[0].reset();
                resetReplacement();
                loadDocuments();
            })
            .fail(function (xhr) {
                showDocumentMessage(xhr.responseJSON?.error || "Document ingestion failed.", "danger");
            })
            .always(function () {
                stopIngestionProgress();
                $uploadDocumentButton.prop("disabled", false);
                $cancelReplaceButton.prop("disabled", false);
                $refreshDocumentsButton.prop("disabled", false);
                $uploadDocumentButton.text($replaceDocumentId.val() ? "Replace and re-ingest" : "Upload and ingest");
            });
    });

    function renderEvaluationQuestions() {
        const category = $evaluationCategoryFilter.val();
        const status = $evaluationStatusFilter.val();
        const filtered = evaluationQuestions.filter(function (question) {
            return (!category || question.category === category) && (!status || question.review_status === status);
        });
        $evaluationQuestionList.empty();
        if (!filtered.length) {
            $evaluationQuestionList.append($("<p>").addClass("text-muted").text("No questions match these filters."));
            return;
        }
        filtered.forEach(function (question) {
            const $item = $("<article>").addClass("evaluation-question");
            const $heading = $("<div>").addClass("evaluation-question-heading");
            $heading.append($("<strong>").text(question.display_order + ". " + question.question_text));
            $heading.append($("<span>").addClass("status status-" + (question.review_status === "reviewed" ? "ready" : "planned")).text(titleCaseLabel(question.review_status)));
            $item.append($heading);
            $item.append($("<p>").text(question.expected_answer));
            $item.append($("<small>").text(
                titleCaseLabel(question.category) + " · " + titleCaseLabel(question.difficulty) + " · " +
                (Number(question.is_answerable) ? "Answerable" : "Unanswerable")
            ));
            if (question.expected_source || question.expected_evidence) {
                const $evidence = $("<details>").addClass("evaluation-reference");
                $evidence.append($("<summary>").text("Review cited source evidence"));
                if (question.expected_source) {
                    $evidence.append($("<strong>").text("Expected source: " + question.expected_source));
                }
                if (question.expected_evidence) {
                    $evidence.append($("<blockquote>").text(question.expected_evidence));
                }
                $item.append($evidence);
            }
            const $actions = $("<div>").addClass("evaluation-review-actions").attr("aria-label", "Test-case review status");
            ["reviewed", "needs_revision", "draft"].forEach(function (nextStatus) {
                const labels = {
                    reviewed: "Mark reviewed",
                    needs_revision: "Mark needs revision",
                    draft: "Mark draft",
                };
                $actions.append(
                    $("<button>")
                        .attr("type", "button")
                        .addClass("btn btn-sm btn-outline-secondary evaluation-review-button")
                        .prop("disabled", question.review_status === nextStatus)
                        .data({ questionId: question.question_id, reviewStatus: nextStatus })
                        .text(question.review_status === nextStatus ? labels[nextStatus].replace("Mark ", "Currently ") : labels[nextStatus])
                );
            });
            $item.append($actions);
            $evaluationQuestionList.append($item);
        });
    }

    function readable(value, fallback) {
        if (value === null || value === undefined || value === "") {
            return fallback || "Not recorded";
        }
        return String(value).replaceAll("_", " ");
    }

    function titleCaseLabel(value, fallback) {
        return readable(value, fallback).replace(/\b\w/g, function (character) {
            return character.toUpperCase();
        });
    }

    function modelDisplayName(model) {
        const labels = {
            "gemini-2.5-flash": "Gemini 2.5 Flash — standard",
            "gemini-3.1-flash-lite": "Gemini 3.1 Flash-Lite — faster",
            "gemini-3.6-flash": "Gemini 3.6 Flash",
            "qwen2.5vl:7b": "Qwen 2.5 VL 7B - Local Ollama",
        };
        return labels[String(model || "")] || titleCaseLabel(model, "Model not recorded");
    }

    function retrievalDisplayName(method) {
        return {
            mysql_keyword: "Keyword search",
            chroma_vector: "Vector search",
            hybrid_rrf: "Hybrid search",
        }[String(method || "")] || titleCaseLabel(method, "Retrieval not recorded");
    }

    function normalizeCategoryKey(value) {
        return String(value || "")
            .trim()
            .toLowerCase()
            .replace(/&/g, " and ")
            .replace(/[^a-z0-9]+/g, "_")
            .replace(/^_+|_+$/g, "");
    }

    const evaluatorGoalRecommendations = {
        overall: {
            primary: "Run the local ten across the full reviewed test set.",
            secondary: "Use the LLM judge and RAGAS on representative, difficult, changed, or failing answers; add human review where methods disagree.",
            caution: "Overall confidence comes from a profile of evidence. No single score proves that an answer is correct, complete, grounded, and useful.",
            reference: "Gold Standard recommended: it supplies verified correctness, source, fact, and answerability expectations.",
        },
        correctness: {
            primary: "Required-fact coverage plus the versioned LLM judge.",
            secondary: "Use exact/accepted variants and semantic or BERTScore signals for regression, then human-review important disagreements.",
            caution: "Similarity can remain high when one date or number is wrong; fact coverage can miss unsupported extra claims.",
            reference: "Gold Standard required: correctness and completeness need a reviewed answer, facts, and evidence.",
        },
        grounding: {
            primary: "RAGAS Faithfulness beside the exact retrieved source chunks.",
            secondary: "Add the judge faithfulness rubric and human inspection for consequential claims.",
            caution: "A response can be faithful to retrieved context that is itself irrelevant, incomplete, or outdated.",
            reference: "Gold Standard optional for the primary check: Faithfulness uses the saved answer and contexts; reviewed evidence is still needed to judge correctness.",
        },
        retrieval: {
            primary: "Expected-source accuracy, including the saved source rank.",
            secondary: "Add RAGAS Context Precision for ranking/noise and Context Recall for missing evidence; inspect the chunks directly.",
            caution: "Finding the expected document does not prove that the selected passage was sufficient or used correctly.",
            reference: "Gold Standard required in this project: retrieval claims use an expected source, answer, and verified evidence.",
        },
        relevance: {
            primary: "RAGAS Response Relevancy.",
            secondary: "Add correctness and faithfulness evidence so a direct but false answer is not rewarded.",
            caution: "Relevance only shows that the response addresses the question; it does not prove truth or grounding.",
            reference: "Gold Standard optional for the primary check: Response Relevancy compares the question and saved answer.",
        },
        refusal: {
            primary: "Refusal correctness against the reviewed answerability label.",
            secondary: "Add the LLM judge refusal rubric and human review for ambiguous or high-risk questions.",
            caution: "A correct refusal decision does not measure the quality of an answerable response.",
            reference: "Gold Standard required: the evaluator needs a reviewed decision about whether the corpus can answer the question.",
        },
        regression: {
            primary: "Apply all eight local methods to every saved answer.",
            secondary: "Run advanced methods only on changed, below-threshold, difficult, or sampled cases, then calibrate with human review.",
            caution: "Project thresholds are review flags, not factual verdicts; inspect every flagged response and its evidence.",
            reference: "Gold Standard recommended: repeatable regression needs a stable reviewed test set and frozen run configuration.",
        },
    };

    function renderEvaluatorGoalRecommendation() {
        const recommendation = evaluatorGoalRecommendations[String($evaluatorGoalSelect.val() || "overall")] ||
            evaluatorGoalRecommendations.overall;
        $evaluatorGoalPrimary.text(recommendation.primary);
        $evaluatorGoalSecondary.text(recommendation.secondary);
        $evaluatorGoalCaution.text(recommendation.caution);
        $evaluatorGoalReference.text(recommendation.reference);
    }

    $evaluatorGoalSelect.on("change", renderEvaluatorGoalRecommendation);
    renderEvaluatorGoalRecommendation();

    function compactNumber(value, digits) {
        const number = Number(value);
        return Number.isFinite(number) ? number.toFixed(digits === undefined ? 3 : digits) : "N/A";
    }

    function evaluatorMethodKey(evaluator) {
    const key = String(evaluator.evaluator_key || "");

    if (["citation_coverage", "citation_support"].includes(key)) {
        return "citation";
    }

    if (Number(evaluator.is_local) === 1) {
        return "local";
    }
    if (evaluator.evaluator_key === "llm_judge") {
        return "judge";
    }
    if (key.startsWith("ragas_")) {
        return "ragas";
    }
    return "model";
}

    function evaluatorMethodLabel(evaluator) {
        return {
            local: "Local metric",
            judge: "LLM judge",
            ragas: "RAGAS",
            model: "Model-backed metric",
            citation: "AI citation analysis",
        }[evaluatorMethodKey(evaluator)];
    }

    function requiresGoldStandard(evaluator) {
        const noGoldStandardRequired = [
            "ragas_faithfulness",
            "ragas_response_relevancy",
            "citation_validity",
            "citation_presence",
            "citation_support",
            "citation_coverage"
        ];

        return !noGoldStandardRequired.includes(
            String(evaluator.evaluator_key || "")
        );
    }
    function hasGoldStandardReference(response) {
    return response.is_answerable !== null &&
        response.is_answerable !== undefined;
}

function applicableEvaluators(methodKey, response, results) {
    const hasReference = hasGoldStandardReference(response);
    const historicalKeys = new Set(
        (results || []).map(function (result) {
            return String(result.evaluator_key || "");
        })
    );

    return evaluatorCatalog.filter(function (evaluator) {
        if (evaluatorMethodKey(evaluator) !== methodKey) {
            return false;
        }

        return hasReference ||
            !requiresGoldStandard(evaluator) ||
            historicalKeys.has(String(evaluator.evaluator_key || ""));
    });
}
    function methodStatusCounts(results) {
        return {
            completed: results.filter(function (result) { return result.status === "completed"; }).length,
            failed: results.filter(function (result) { return result.status === "failed"; }).length,
            skipped: results.filter(function (result) { return result.status === "skipped"; }).length,
        };
    }

    function methodStatusDetails(counts, total, recorded) {
        const details = [];
        if (counts.failed) {
            details.push(counts.failed + " failed");
        }
        if (counts.skipped) {
            details.push(counts.skipped + " skipped");
        }
        const notRun = Math.max(0, total - recorded);
        if (notRun) {
            details.push(notRun + " not run");
        }
        return details.length ? details.join(" · ") : "No failures, skips, or missing methods";
    }

    function renderEvaluationMethodSummary(data) {
        const results = data.results || [];
        const reviews = data.human_reviews || [];
        const response = data.response || {};
        const definitions = [
            { key: "local", label: "Local metrics" },
            { key: "judge", label: "LLM judge" },
            { key: "ragas", label: "RAGAS" },
            { key: "citation", label: "AI Citation Analysis"},
        ];
        const $section = $("<section>").addClass("response-method-section");
        $section.append($("<div>").addClass("subsection-heading").append(
            $("<span>").text("How this answer was evaluated"),
            $("<strong>").text("Completed, failed, and missing checks are kept separate")
        ));
        const $summary = $("<div>").addClass("response-method-summary");
        definitions.forEach(function (definition) {
            const methodResults = results.filter(function (result) {
                return evaluatorMethodKey(result) === definition.key;
            });

            const eligibleMethods = applicableEvaluators(
                definition.key,
                response,
                results
            );

            if (!eligibleMethods.length && !methodResults.length) {
                return;
            }

            const total = eligibleMethods.length;

            const counts = methodStatusCounts(methodResults);
            let headline = counts.completed + " of " + total + " completed";
            if (definition.key === "judge" && total === 1) {
                headline = counts.completed ? "Completed" : counts.failed ? "Failed" : counts.skipped ? "Skipped" : "Not run";
            }
            $summary.append($("<article>").addClass("method-summary method-summary-" + definition.key).append(
                $("<span>").text(definition.label),
                $("<strong>").text(headline),
                $("<small>").text(methodStatusDetails(counts, total, methodResults.length))
            ));
        });
        $summary.append($("<article>").addClass("method-summary method-summary-human").append(
            $("<span>").text("Human review"),
            $("<strong>").text(reviews.length ? "Reviewed" : "Not reviewed"),
            $("<small>").text(reviews.length
                ? reviews.length + " current rubric decision" + (reviews.length === 1 ? "" : "s") + "; supporting evidence, not an automatic metric"
                : "Supporting evidence, not an automatic metric")
        ));
        $section.append($summary);
        $evaluationResultDetail.append($section);
    }

    function appendContract($container, configuration) {
        const contract = configuration || {};
        const direction = contract.direction === "higher_is_better" ? "score ≥"
            : contract.direction === "lower_is_better" ? "score ≤" : readable(contract.direction, "score");
        const $details = $("<details>").addClass("score-contract");
        $details.append($("<summary>").text("What this score means"));
        const fields = [
            ["Question", contract.question],
            ["Compared with", contract.comparison_target],
            ["Calculation", contract.calculation],
            ["Scale", contract.scale],
            ["Review rule", contract.threshold === null || contract.threshold === undefined
                ? "No threshold; inspect the value directly."
                : direction + " " + contract.threshold + " (" + readable(contract.threshold_status, "status unknown") + ")"],
            ["Limitation", contract.limitation],
        ];
        const $list = $("<dl>");
        fields.forEach(function (field) {
            if (field[1] !== null && field[1] !== undefined && field[1] !== "") {
                $list.append($("<div>").append($("<dt>").text(field[0]), $("<dd>").text(field[1])));
            }
        });
        $details.append($list);
        $container.append($details);
    }

    function renderFindings(data) {
        const findings = data.findings || {};
        const layers = findings.layers || {};
        $findingBaselineCount.text(layers.baseline || 0);
        $findingAdvancedCount.text(layers.advanced || 0);
        $findingHumanCount.text(findings.human_review_count || 0);

        $findingRules.empty();
        (findings.interpretation_rules || []).forEach(function (rule) {
            $findingRules.append($("<li>").text(rule));
        });

        $findingMatchedComparisons.empty();
        (findings.matched_comparisons || []).forEach(function (comparison) {
            const delta = Number(comparison.mean_delta);
            const comparisonRun = (data.runs || []).find(function (run) {
                return Number(run.run_id) === Number(comparison.comparison_run_id);
            });
            const baselineRun = (data.runs || []).find(function (run) {
                return Number(run.run_id) === Number(comparison.baseline_run_id);
            });
            const $card = $("<article>").addClass("matched-comparison-card");
            $card.append($("<span>").text(
                (comparisonRun?.run_name || "Comparison test") + " compared with " +
                (baselineRun?.run_name || "saved baseline")
            ));
            $card.append($("<strong>").text(comparison.display_name));
            $card.append($("<b>").text(
                (delta >= 0 ? "+" : "") + compactNumber(delta) + " mean delta"
            ));
            $card.append($("<p>").text(
                comparison.paired_question_count + " matched question" +
                (Number(comparison.paired_question_count) === 1 ? "" : "s") +
                " · baseline " + compactNumber(comparison.baseline_mean) +
                " · comparison " + compactNumber(comparison.comparison_mean)
            ));
            $findingMatchedComparisons.append($card);
        });
        if (!$findingMatchedComparisons.children().length) {
            $findingMatchedComparisons.append($("<div>").addClass("matched-comparison-empty").append(
                $("<strong>").text("No valid paired comparison exists yet."),
                $("<p>").text("No completed baseline pair currently shares scored question/evaluator rows. Scores remain run-scoped descriptive evidence, so no improvement claim is calculated.")
            ));
        }

        $findingRunComparison.empty();
        (data.runs || []).forEach(function (run) {
            const $card = $("<article>").addClass("finding-run-card");
            const configuration = run.run_configuration_json || {};
            const coverage = Number(run.dataset_question_count)
                ? Math.round((Number(run.response_count) / Number(run.dataset_question_count)) * 100)
                : 0;
            $card.append($("<div>").addClass("finding-run-title").append(
                $("<span>").text("Saved test"),
                $("<strong>").text(run.run_name),
                $("<em>").addClass("run-status run-status-" + run.status).text(titleCaseLabel(run.status))
            ));
            $card.append($("<p>").text(
                retrievalDisplayName(run.retrieval_method) + " · " + run.top_k + " retrieved sources · " +
                (run.response_count || 0) + "/" + (run.dataset_question_count || evaluationDatasetQuestionCount) +
                " answers (" + coverage + "% test-set coverage)"
            ));
            const $facts = $("<dl>").addClass("finding-run-facts");
            [
                ["Test purpose", run.experiment_key || "not labeled"],
                ["Source collection", titleCaseLabel(run.corpus_variant_key, "Full corpus")],
                ["Completed checks", (run.completed_result_count || 0) + " completed"],
                ["Recorded method statuses", (run.result_count || 0) + " total"],
                ["Evaluator attempts", (run.evaluator_attempt_count || 0) + " retained"],
                ["Skipped / failed", (run.evaluator_skipped_count || 0) + " / " + (run.evaluator_error_count || 0)],
                ["Evaluator runtime", compactNumber((Number(run.evaluator_runtime_ms) || 0) / 1000, 2) + " s"],
                ["Generation cost", Number(run.generation_unpriced_count)
                    ? "Unknown for " + run.generation_unpriced_count + " response(s)"
                    : "$" + compactNumber(run.answer_estimated_cost || 0, 6)],
                ["Provider evaluator cost", Number(run.evaluator_unpriced_count)
                    ? "Unknown for " + run.evaluator_unpriced_count + " attempt(s)"
                    : run.evaluator_priced_count
                        ? "$" + compactNumber(run.evaluator_estimated_cost, 6)
                        : "No provider attempts"],
            ].forEach(function (fact) {
                $facts.append($("<div>").append($("<dt>").text(fact[0]), $("<dd>").text(fact[1])));
            });
            $card.append($facts);
            if (configuration.change_from_baseline) {
                $card.append($("<p>").addClass("finding-change-note").text("Changed variable: " + configuration.change_from_baseline));
            }
            const scopedMetrics = (findings.run_metric_summaries || []).filter(function (metric) {
                return Number(metric.run_id) === Number(run.run_id);
            });
            if (scopedMetrics.length) {
                const $scoped = $("<details>").addClass("run-scoped-metrics");
                $scoped.append($("<summary>").text("Run-scoped metric means (" + scopedMetrics.length + ")"));
                const $list = $("<dl>");
                scopedMetrics.forEach(function (metric) {
                    $list.append($("<div>").append(
                        $("<dt>").text(metric.display_name + " · n=" + metric.question_count),
                        $("<dd>").text(compactNumber(metric.mean_score))
                    ));
                });
                $scoped.append($list);
                $card.append($scoped);
            }
            $findingRunComparison.append($card);
        });
        if (!$findingRunComparison.children().length) {
            $findingRunComparison.append($("<p>").addClass("text-muted").text("No batch test runs have been saved."));
        }

        $findingMetricCatalog.empty();
        (findings.metric_summaries || []).forEach(function (metric) {
            const config = metric.configuration_json || {};
            const $card = $("<article>").addClass("finding-metric metric-" + (metric.layer || "baseline"));
            $card.append($("<div>").addClass("finding-metric-heading").append(
                $("<span>").text(evaluatorMethodLabel(metric)),
                $("<strong>").text(metric.display_name)
            ));
            $card.append($("<p>").text(config.question || "No score question documented."));
            $card.append($("<small>").addClass("metric-dependency").text(
                requiresGoldStandard(metric)
                    ? "Gold-standard data required · post-answer evaluation"
                    : "No gold answer required · post-answer evaluation"
            ));
            const completed = Number(metric.completed_count) || 0;
            $card.append($("<small>").text(completed
                ? completed + " completed across stored responses · inspect run-scoped or matched evidence above"
                : "Not run yet · no observed scores are being inferred"
            ));
            const costText = Number(metric.is_local)
                ? "local method; no provider cost"
                : Number(metric.unpriced_attempt_count)
                    ? "cost unknown for " + metric.unpriced_attempt_count + " provider attempt(s)"
                : Number(metric.priced_attempt_count)
                    ? "recorded cost $" + compactNumber(metric.estimated_cost, 6)
                    : "no provider cost";
            $card.append($("<small>").addClass("metric-operations").text(
                (metric.attempt_count || 0) + " attempts · mean runtime " +
                compactNumber(metric.mean_runtime_ms || 0, 1) + " ms · " + costText
            ));
            appendContract($card, config);
            $findingMetricCatalog.append($card);
        });
    }

    let evaluationDatasetRequestId = 0;
    function loadEvaluationDataset(completionMessage = null, completionRunId = null) {
        const requestId = ++evaluationDatasetRequestId;
        const completionTarget = function () {
            const $run = $evaluationRunList
                .find('.evaluation-run[data-run-id="' + completionRunId + '"]')
                .first();
            return $run.length ? $run : $evaluationRunList;
        };
        const selectedDatasetId = $evaluationDatasetSelect.val();

        const requestUrl = selectedDatasetId
            ? "api/evaluations.php?dataset_id=" +
              encodeURIComponent(selectedDatasetId)
            : "api/evaluations.php";

        $.getJSON(requestUrl)
            .done(function (response) {
                if (requestId !== evaluationDatasetRequestId) {
                    return;
                }

                const data = response.data;
                evaluationQuestions = data.questions || [];
                evaluatorCatalog = data.evaluators || [];
                refreshDashboardEvaluatorCatalog();
                const dataset = data.dataset;
                const availableDatasets = data.availableDatasets || [];
                $evaluationDatasetSelect.empty();

                availableDatasets.forEach(function (availableDataset) {
                    const label =
                        availableDataset.dataset_name +
                        " v" + availableDataset.version +
                        " (" + availableDataset.status + ")";

                    $evaluationDatasetSelect.append(
                        $("<option>")
                            .val(String(availableDataset.dataset_id))
                            .text(label)
                    );
                });

                if (dataset) {
                    $evaluationDatasetSelect.val(String(dataset.dataset_id));
                }
                if (!dataset) {
                    evaluationDatasetQuestionCount = 0;
                    evaluationRuns = [];
                    populateNewTestBaselines();
                    $evaluationDatasetSummary.text("No evaluation dataset has been seeded.");
                    renderResearchReadiness(null, [], {});
                    return;
                }
                evaluationDatasetQuestionCount = Number(dataset.question_count) || 0;
                $newTestDatasetId.val(dataset.dataset_id);
                populateNewTestQuestionChoices();
                evaluationRuns = data.runs || [];
                populateNewTestBaselines();
                $evaluationQuestionCount.text(dataset.question_count);
                $experimentDatasetCount.text(dataset.question_count);
                const readyRunCount = evaluationRuns.filter(function (run) {
                    return run.status === "completed";
                }).length;
                const attentionRunCount = Math.max(0, evaluationRuns.length - readyRunCount);
                $experimentRunCount.text(readyRunCount);
                $experimentRunCountNote.text(
                    attentionRunCount
                        ? attentionRunCount + " archived interrupted attempt" + (attentionRunCount === 1 ? "" : "s")
                        : "completed batches"
                );
                $evaluationDatasetSummary.text(
                    dataset.dataset_name + " " + dataset.version + ": " + dataset.reviewed_count + " of " + dataset.question_count +
                    " reviewed; " + dataset.unanswerable_count + " unanswerable cases across " + dataset.category_count + " categories."
                );
                $evaluatorCount.text(dashboardEvaluatorCatalog.length);
                $overviewEvaluatorCount.text(dashboardEvaluatorCatalog.length);
                $experimentHumanReviewCount.text(data.findings?.human_review_count || 0);
                renderResearchReadiness(dataset, evaluationRuns, data.findings || {});
                $evaluatorSummary.text(
                    "Choose a saved test or standalone Chat answer to inspect its evaluation results. " +
                    "The catalog contains " + dashboardEvaluatorCatalog.length + " evaluation methods, " +
                    "including optional advanced and citation metrics. " +
                    "Scoring can reuse saved results, and local checks do not require an external API call."
                );
                const categories = [...new Set(evaluationQuestions.map(function (question) { return question.category; }))].sort();
                $evaluationCategoryFilter.find("option:not(:first)").remove();
                categories.forEach(function (value) {
                    $evaluationCategoryFilter.append($("<option>").val(value).text(titleCaseLabel(value)));
                });
                renderEvaluationQuestions();
                renderEvaluationRuns(
                    evaluationRuns,
                    data.responses || [],
                    data.findings || {},
                    data.standaloneResponses || []
                );
                renderFindings(data);
                if (completionMessage) {
                    $(".evaluation-completion-notice").remove();
                    $("<p>")
                        .addClass("run-evaluation-status evaluation-completion-notice")
                        .attr({ role: "status", "aria-live": "polite" })
                        .text(completionMessage)
                        .insertBefore(completionTarget());
                }
            })
            .fail(function () {
                  if (requestId !== evaluationDatasetRequestId) {
                      return;
                  }
                if (completionMessage) {
                    $(".evaluation-completion-notice").remove();
                    $("<p>")
                        .addClass("run-evaluation-status evaluation-completion-notice")
                        .attr({ role: "alert" })
                        .text("Scoring finished, but saved results could not be refreshed. Reload the dataset to verify the updated scores.")
                        .insertBefore(completionTarget());
                }
                $evaluationDatasetSummary.text("Evaluation data is temporarily unavailable. Try again or contact the application administrator.");
                $researchReadinessList.empty().append(
                    $("<li>").addClass("readiness-next").text("Study status is unavailable until the application data can be loaded.")
                );
            });
    }

    function renderResearchReadiness(dataset, runs, findings) {
        const completedRuns = (runs || []).filter(function (run) { return run.status === "completed"; });
        const controlledBaselines = completedRuns.filter(function (run) {
            return run.experiment_key && !run.baseline_run_id;
        });
        const matchedCount = (findings.matched_comparisons || []).length;
        const humanReviewCount = Number(findings.human_review_count) || 0;
        const reviewedCount = Number(dataset?.reviewed_count) || 0;
        const questionCount = Number(dataset?.question_count) || 0;
        const items = [
            {
                ready: questionCount > 0 && reviewedCount === questionCount,
                readyText: "Gold Standard ready · " + reviewedCount + " of " + questionCount + " questions reviewed",
                nextText: "Review the Gold Standard · " + reviewedCount + " of " + questionCount + " questions are ready",
                href: "#evaluation",
            },
            {
                ready: controlledBaselines.length > 0,
                readyText: "Controlled baseline saved · " + controlledBaselines.length + " available",
                nextText: "Create a controlled baseline from New test run",
                href: "#results",
            },
            {
                ready: matchedCount > 0,
                readyText: "Matched comparison evidence ready · " + matchedCount + " metric pair" + (matchedCount === 1 ? "" : "s"),
                nextText: "Run a one-setting comparison against the saved baseline",
                href: "#results",
            },
            {
                ready: humanReviewCount > 0,
                readyText: "Human review evidence saved · " + humanReviewCount + " current review" + (humanReviewCount === 1 ? "" : "s"),
                nextText: "Open representative saved answers and add human reviews",
                href: "#results",
            },
            {
                ready: completedRuns.length > 0,
                readyText: "Report exports available on every completed test",
                nextText: "Complete a test to unlock JSON and CSV report evidence",
                href: "#results",
            },
        ];
        $researchReadinessList.empty();
        items.forEach(function (item) {
            const $link = $("<a>").attr("href", item.href).text(item.ready ? item.readyText : item.nextText);
            $researchReadinessList.append(
                $("<li>").addClass(item.ready ? "readiness-ready" : "readiness-next").append(
                    $("<span>").attr("aria-hidden", "true").text(item.ready ? "✓" : "→"),
                    $link
                )
            );
        });
    }

    function savedTestDate(value) {
        if (!value) {
            return "Date unavailable";
        }
        const parsed = new Date(String(value).replace(" ", "T"));
        return Number.isNaN(parsed.getTime())
            ? String(value)
            : new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", year: "numeric" }).format(parsed);
    }

    function runScoringState(run, runResponses) {
        const responseCount = runResponses.length;
        const completed = runResponses.reduce(function (total, response) {
            return total + (Number(response.completed_result_count) || 0);
        }, 0);
        const skipped = runResponses.reduce(function (total, response) {
            return total + (Number(response.skipped_result_count) || 0);
        }, 0);
        const failed = runResponses.reduce(function (total, response) {
            return total + (Number(response.failed_result_count) || 0);
        }, 0);
        const localCompleted = runResponses.reduce(function (total, response) {
            return total + (Number(response.local_completed_count) || 0);
        }, 0);
        const localSkipped = runResponses.reduce(function (total, response) {
            return total + (Number(response.local_skipped_count) || 0);
        }, 0);
        const localFailed = runResponses.reduce(function (total, response) {
            return total + (Number(response.local_failed_count) || 0);
        }, 0);
        if (run.status !== "completed") {
            return {
                label: "Archived attempt",
                className: "run-status-attention",
            };
        }
        const fullEvaluatorCount = 15;
        const allResponsesFullyScored = responseCount > 0 &&
            runResponses.every(function (response) {
                const resolved =
                    (Number(response.completed_result_count) || 0) +
                    (Number(response.skipped_result_count) || 0);
                const errors = Number(response.failed_result_count) || 0;
                return !errors && resolved >= fullEvaluatorCount;
            });
        if (allResponsesFullyScored) {
            return { label: "Full evaluator set available", className: "run-status-completed" };
        }
        const configuration = run.run_configuration_json || {};
        const configuredLocalCount = Array.isArray(configuration.evaluators)
            ? configuration.evaluators.length
            : 0;
        const recordedLocalCount = runResponses.reduce(function (maximum, response) {
            const count =
                (Number(response.local_completed_count) || 0) +
                (Number(response.local_skipped_count) || 0) +
                (Number(response.local_failed_count) || 0);
            return Math.max(maximum, count);
        }, 0);
        const expectedLocalSlots = responseCount *
            Math.max(configuredLocalCount, recordedLocalCount);
        if (responseCount && expectedLocalSlots > 0 && !localFailed &&
                localCompleted + localSkipped >= expectedLocalSlots) {
            return { label: "Local evaluation complete", className: "run-status-local" };
        }
        return { label: "Local evaluation incomplete", className: "run-status-attention" };
    }

    function renderRunCard(run, responses, findings) {
        const runResponses = responses.filter(function (response) {
            return String(response.run_id) === String(run.run_id);
        });
        const responseCount = runResponses.length;
        const localCompletedCount = runResponses.reduce(function (total, response) {
            return total + (Number(response.local_completed_count) || 0);
        }, 0);
        const localSkippedCount = runResponses.reduce(function (total, response) {
            return total + (Number(response.local_skipped_count) || 0);
        }, 0);
        const completedCount = runResponses.reduce(function (total, response) {
            return total + (Number(response.completed_result_count) || 0);
        }, 0);
        const configuration = run.run_configuration_json || {};
        const configuredLocalCount = Array.isArray(configuration.evaluators)
            ? configuration.evaluators.length
            : 0;
        const recordedLocalCount = runResponses.reduce(function (maximum, response) {
            const count =
                (Number(response.local_completed_count) || 0) +
                (Number(response.local_skipped_count) || 0) +
                (Number(response.local_failed_count) || 0);
            return Math.max(maximum, count);
        }, 0);
        const localExpectedSlots = responseCount *
            Math.max(configuredLocalCount, recordedLocalCount);
        const state = runScoringState(run, runResponses);
        const $run = $("<article>").addClass("evaluation-run").attr("data-run-id", run.run_id);
        const $runHeading = $("<div>").addClass("evaluation-run-heading");
        $runHeading.append($("<strong>").text("Saved " + savedTestDate(run.completed_at || run.started_at)));
        $runHeading.append($("<span>").addClass("run-status " + state.className).text(state.label));
        $run.append($runHeading);
        $run.append($("<h3>").text(run.run_name));
        const localResolvedCount = localCompletedCount + localSkippedCount;
        let coverageText = localResolvedCount + " of " + localExpectedSlots + " local checks resolved";
        if (state.className === "run-status-completed") {
            coverageText = "full evaluator coverage recorded";
        } else if (state.className === "run-status-local") {
            coverageText += (localSkippedCount ? " · " + localSkippedCount + " not applicable" : "") +
                " · advanced checks optional";
        }
        $run.append($("<span>").addClass("evaluation-run-meta").text(
            responseCount + " saved answer" + (responseCount === 1 ? "" : "s") + " · " + coverageText
        ));
        $run.append($("<p>").addClass("evaluation-run-scope").text(
            "Saved scope: " + responseCount + " answer" + (responseCount === 1 ? "" : "s") +
            (evaluationDatasetQuestionCount ? " from the " + evaluationDatasetQuestionCount + "-question Gold Standard." : ".")
        ));
        if (run.baseline_run_id) {
            const baseline = evaluationRuns.find(function (candidate) {
                return Number(candidate.run_id) === Number(run.baseline_run_id);
            });
            $run.append($("<p>").addClass("evaluation-run-experiment").text(
                "Controlled comparison" + (run.experiment_key ? " · " + run.experiment_key : "") +
                " · baseline: " + (baseline ? baseline.run_name : "selected saved baseline") +
                (configuration.change_from_baseline ? " · changed: " + configuration.change_from_baseline : "")
            ));
        } else if (run.experiment_key) {
            $run.append($("<p>").addClass("evaluation-run-experiment").text(
                "Controlled baseline · " + run.experiment_key + " · ready for a one-setting comparison"
            ));
        }

        const skipped = Number(run.evaluator_skipped_count) || 0;
        const failed = Number(run.evaluator_error_count) || 0;
        if (skipped || failed) {
            $run.append($("<p>").addClass("evaluation-run-note").text(
                completedCount + " completed · " + skipped + " skipped · " + failed +
                " failed. Missing, skipped, and failed methods are not treated as zero scores."
            ));
        }
        if (run.status !== "completed") {
            $run.append($("<p>").addClass("evaluation-run-warning").text(
                responseCount
                    ? "This archived test stopped early, but its saved answer is still available. Use Score saved answers to add the missing checks."
                    : "This archived test stopped before it saved an answer. It is preserved only as technical history."
            ));
        }

        const $settings = $("<details>").addClass("run-settings");
        $settings.append($("<summary>").text("Settings and technical record"));
        $settings.append($("<p>").text(
            retrievalDisplayName(run.retrieval_method) + " · " +
            modelDisplayName(run.chat_model) + " · retrieved sources " + readable(run.top_k, "unknown") +
            " · temperature " + readable(run.temperature, "unknown") +
            " · top-p " + readable(run.top_p, "unknown") + " · sources: " +
            controlledSettingDisplay("corpus", Array.isArray(configuration.categories) ? configuration.categories : []) +
            " · internal run ID " + run.run_id
        ));
        $run.append($settings);

        const exportBase = "api/exports.php?run_id=" + encodeURIComponent(run.run_id) + "&format=";
        const $exportActions = $("<div>").addClass("run-export-actions").append(
            $("<span>").text("Download this test for the report:"),
            $("<a>")
                .addClass("btn btn-sm btn-outline-secondary")
                .attr({ href: exportBase + "json", download: "" })
                .text("Export JSON"),
            $("<a>")
                .addClass("btn btn-sm btn-outline-secondary")
                .attr({ href: exportBase + "csv", download: "" })
                .text("Export CSV")
        );
        $run.append($exportActions);

        const $evaluateActions = $("<div>").addClass("run-evaluation-actions");
        const $evaluateToggle = $("<button>")
            .attr("type", "button")
            .addClass("btn btn-sm btn-primary evaluate-run-toggle")
            .prop("disabled", !responseCount)
            .text("Score saved answers");
        const $evaluatePanel = $("<div>")
            .addClass("run-evaluation-panel")
            .prop("hidden", true)
            .data({ runId: run.run_id, responseCount: responseCount });
        $evaluatePanel.append($("<p>").addClass("run-evaluation-explainer").text(
            "This applies scoring methods to the saved text above. It will not ask the LLM to generate another answer."
        ));
        const $scopeLabel = $("<label>").addClass("run-evaluation-field").append(
            $("<span>").text("What should be scored?")
        );
        const $scope = $("<select>")
            .addClass("form-select form-select-sm run-evaluation-scope")
            .attr("aria-label", "Scoring scope")
            .append(
                $("<option>").val("local8").text("Local 10 · every saved answer · no API calls"),
                $("<option>").val("all13").text("All 15 · one selected answer · may use API quota")
            );
        $scopeLabel.append($scope);
        const $targetSelect = $("<select>")
            .addClass("form-select form-select-sm run-evaluation-target-select")
            .attr("aria-label", "Saved answer to score");
        runResponses.forEach(function (response, index) {
            const questionNumber = Number(response.run_question_number) || index + 1;
            $targetSelect.append(
                $("<option>").val(response.response_id).text(
                    "Question " + questionNumber + ": " + response.question_text
                )
            );
        });
        const $targetLabel = $("<label>")
            .addClass("run-evaluation-field run-evaluation-target")
            .prop("hidden", true)
            .append($("<span>").text("Which saved answer?"), $targetSelect);
        const $advancedOptions = $("<details>").addClass("run-evaluation-advanced");
        $advancedOptions.append($("<summary>").text("Advanced option"));
        $advancedOptions.append($("<label>").addClass("run-evaluation-force").append(
            $("<input>").attr("type", "checkbox").addClass("form-check-input run-evaluation-force-input"),
            $("<span>").text("Replace scores that already completed")
        ));
        const $preview = $("<button>")
            .attr("type", "button")
            .addClass("btn btn-sm btn-outline-primary preflight-run-evaluation")
            .text("Check what will run");
        const $execute = $("<button>")
            .attr("type", "button")
            .addClass("btn btn-sm btn-primary execute-run-evaluation")
            .prop("hidden", true)
            .text("Apply scores");
        const $status = $("<p>").addClass("run-evaluation-status").attr({ role: "status", "aria-live": "polite" }).text(
            "Start with the local ten. Completed scores will be reused unless the advanced replacement option is selected."
        );
        $evaluatePanel.append(
            $scopeLabel,
            $targetLabel,
            $advancedOptions,
            $("<div>").addClass("run-evaluation-buttons").append($preview, $execute),
            $status
        );
        $evaluateActions.append($evaluateToggle, $evaluatePanel);
        $run.append($evaluateActions);

        const $questionHeading = $("<div>").addClass("run-question-heading").append(
            $("<strong>").text("Answered questions"),
            $("<small>").text("Open inspects evidence · Evaluate prepares all 15 methods for that answer")
        );
        $run.append($questionHeading);
        const $buttons = $("<div>").addClass("evaluation-response-buttons");
        runResponses.forEach(function (response, index) {
            const questionNumber = Number(response.run_question_number) || index + 1;
            const completed = Number(response.completed_result_count) || 0;
            const failedResults = Number(response.failed_result_count) || 0;
            const skippedResults = Number(response.skipped_result_count) || 0;
            const savedRunEvaluatorCount = dashboardEvaluatorCatalog.filter(function (evaluator) {
                return evaluator.evaluator_key !== "citation_coverage" &&
                    evaluator.evaluator_key !== "citation_support";
            }).length;
            const notRun = Math.max(0, savedRunEvaluatorCount - (Number(response.result_count) || 0));
            const statusParts = [completed + " completed"];
            if (failedResults) {
                statusParts.push(failedResults + " failed");
            }
            if (skippedResults) {
                statusParts.push(skippedResults + " skipped");
            }
            if (notRun) {
                statusParts.push(notRun + " not run");
            }
            evaluationResponseContexts.set(Number(response.response_id), {
                label: "Question " + questionNumber + " of " + responseCount,
                runName: run.run_name,
                runId: Number(run.run_id),
            });
            const $responseRow = $("<div>").addClass("evaluation-response-row");
            $responseRow.append(
                $("<button>")
                    .attr("type", "button")
                    .addClass("btn btn-sm btn-outline-primary evaluation-response-button")
                    .data({ responseId: response.response_id, runId: run.run_id })
                    .append(
                        $("<span>").addClass("evaluation-question-number").text("Question " + questionNumber + " of " + responseCount),
                        $("<strong>").text(response.question_text),
                        $("<small>").text(statusParts.join(" · "))
                    )
            );
            $responseRow.append(
                $("<button>")
                    .attr({
                        type: "button",
                        title: "Check and apply all 13 evaluation methods to this saved answer",
                    })
                    .addClass("btn btn-sm btn-primary evaluate-response-button")
                    .data({ responseId: response.response_id, runId: run.run_id })
                    .text("Evaluate")
            );
            $buttons.append($responseRow);
        });
        if (!runResponses.length) {
            $buttons.append($("<p>").addClass("text-muted mb-0").text("No saved answers are available for this test."));
        }
        $run.append($buttons);

        const scopedMetrics = (findings.run_metric_summaries || []).filter(function (metric) {
            return Number(metric.run_id) === Number(run.run_id);
        });
        const globalMetrics = findings.metric_summaries || [];
        const $metricComparison = $("<details>").addClass("run-metric-comparison");
        $metricComparison.append($("<summary>").text("Metric averages for this test and all tests"));
        const $metricTable = $("<div>").addClass("run-metric-table");
        $metricTable.append($("<div>").addClass("run-metric-row run-metric-header").append(
            $("<strong>").text("Method"),
            $("<strong>").text("This test"),
            $("<strong>").text("All tests")
        ));
        dashboardEvaluatorCatalog.forEach(function (evaluator) {
            const current = scopedMetrics.find(function (metric) {
                return metric.evaluator_key === evaluator.evaluator_key;
            });
            const overall = globalMetrics.find(function (metric) {
                return metric.evaluator_key === evaluator.evaluator_key;
            });
            $metricTable.append($("<div>").addClass("run-metric-row").append(
                $("<span>").append(
                    $("<b>").text(evaluator.display_name),
                    $("<small>").text(
                        evaluatorMethodLabel(evaluator) + " · " +
                        (requiresGoldStandard(evaluator) ? "needs gold standard" : "no gold answer required")
                    )
                ),
                $("<span>").text(current
                    ? compactNumber(current.mean_score) + " · n=" + current.question_count
                    : "Not completed"),
                $("<span>").text(overall && overall.mean_score !== null
                    ? compactNumber(overall.mean_score) + " · n=" + overall.completed_count
                    : "Not completed")
            ));
        });
        $metricComparison.append($metricTable);
        $run.append($metricComparison);
        return $run;
    }

    function renderStandaloneResponses(responses) {
        const $section = $("<details>")
            .addClass("standalone-response-section")
            .prop("open", true);

        $section.append(
            $("<summary>").text(
                "Chat and standalone answers (" + responses.length + ")"
            )
        );

        if (!responses.length) {
            $section.append(
                $("<p>").addClass("text-muted")
                    .text("No standalone Chat answers have been saved yet.")
            );
            $standaloneResponseList.append($section);
            return;
        }

        const $search = $("<input>")
            .attr({
                type: "search",
                placeholder: "Search question or response ID",
                "aria-label": "Search standalone answers"
            })
            .addClass("form-control mb-2");

        const $count = $("<small>").addClass("text-muted");
        const $list = $("<div>").addClass("evaluation-response-buttons");

        const $showMore = $("<button>")
            .attr("type", "button")
            .addClass("btn btn-sm btn-outline-secondary mt-2")
            .text("Show more answers");

        const $showFewer = $("<button>")
            .attr("type", "button")
            .addClass("btn btn-sm btn-outline-secondary mt-2")
            .text("Show fewer answers");

        let visibleLimit = 10;

        // Register all responses, including those initially hidden.
        responses.forEach(function (response) {
            const responseId = Number(response.response_id);

            evaluationResponseContexts.set(responseId, {
                response_id: responseId,
                run_id: null,
                question_id: response.question_id || null,
                question_text: response.question_text
            });
        });

        function updateList() {
            const query = $search.val().trim().toLowerCase();

            const filtered = responses.filter(function (response) {
                return String(response.response_id).includes(query) ||
                    String(response.question_text || "")
                        .toLowerCase()
                        .includes(query);
            });

            $list.empty();

            filtered.slice(0, visibleLimit).forEach(function (response) {
                const responseId = Number(response.response_id);
                const completedCount =
                    Number(response.completed_result_count) || 0;

                const $button = $("<button>")
                    .attr("type", "button")
                    .attr("aria-pressed",
                        currentEvaluationResponseId === responseId
                            ? "true" : "false")
                    .addClass(
                        "btn btn-sm btn-outline-primary evaluation-response-button"
                    )
                    .toggleClass(
                        "active",
                        currentEvaluationResponseId === responseId
                    )
                    .data("responseId", responseId);

                $button.append(
                    $("<strong>").text("Response #" + responseId),
                    $("<span>").text(
                        response.question_text || "Untitled question"
                    ),
                    $("<small>").text(
                        completedCount + " completed evaluations"
                    )
                );

                const $previewButton = $("<button>")
                    .attr({
                        type: "button",
                        "aria-label": "Preview citation scoring for response " + responseId
                    })
                    .addClass("btn btn-sm btn-outline-secondary preview-standalone-scoring")
                    .data("responseId", responseId)
                    .text("Preview citation scoring");

                const $executeButton = $("<button>")
                    .attr({
                        type: "button",
                        "aria-label": "Run citation scoring for response " + responseId,
                        title: "Preview citation scoring before execution"
                    })
                    .addClass("btn btn-sm btn-primary execute-standalone-scoring")
                    .data("responseId", responseId)
                    .prop("disabled", true)
                    .text("Run citation scoring");

                const $responseRow = $("<div>")
                    .addClass("standalone-response-row");

                const $responseDetails = $("<div>")
                    .addClass("standalone-response-details")
                    .append($button);

                const $responseActions = $("<div>")
                    .addClass("standalone-response-actions")
                    .append($previewButton, " ", $executeButton);

                $responseRow.append($responseDetails, $responseActions);
                $list.append($responseRow);
            });

            $count.text(
                "Showing " +
                Math.min(visibleLimit, filtered.length) +
                " of " + filtered.length + " matching answers"
            );

            $showMore.toggle(filtered.length > visibleLimit);
            $showFewer.toggle(visibleLimit > 10);
        }

        $search.on("input", function () {
            visibleLimit = 10;
            updateList();
        });

        $showMore.on("click", function () {
            visibleLimit += 10;
            updateList();
        });

        $showFewer.on("click", function () {
            visibleLimit = 10;
            updateList();
        });

        $section.append($search, $count, $list, $showMore, " ", $showFewer);
        $standaloneResponseList.append($section);

        updateList();
    }

   function renderEvaluationRuns(runs, responses, findings, standaloneResponses = []) {
        $standaloneResponseList.empty();
        $evaluationRunList.empty();

        evaluationResponseContexts = new Map();
        renderStandaloneResponses(standaloneResponses);

        if (!runs.length) {
            $evaluationRunList.append($("<p>").addClass("text-muted").text("No saved tests are available yet."));
            return;
        }
        const readyRuns = runs.filter(function (run) { return run.status === "completed"; });
        const attentionRuns = runs.filter(function (run) { return run.status !== "completed"; });
        readyRuns.forEach(function (run) {
            $evaluationRunList.append(renderRunCard(run, responses, findings));
        });
        if (attentionRuns.length) {
            const $history = $("<details>").addClass("run-attention-history");
            $history.append($("<summary>").text(
                "Archived interrupted attempts (" + attentionRuns.length + ")"
            ));
            $history.append($("<p>").text(
                "These records are preserved for an honest audit trail and do not indicate that the current application is incomplete. Saved answers can still be inspected or scored."
            ));
            const $historyRuns = $("<div>").addClass("run-attention-list");
            attentionRuns.forEach(function (run) {
                $historyRuns.append(renderRunCard(run, responses, findings));
            });
            $history.append($historyRuns);
            $evaluationRunList.append($history);
        }
        const preferredRun = readyRuns.slice().sort(function (left, right) {
            return (Number(right.human_review_count) || 0) - (Number(left.human_review_count) || 0) ||
                (Number(right.completed_result_count) || 0) - (Number(left.completed_result_count) || 0) ||
                Number(right.run_id) - Number(left.run_id);
        })[0];
        let $responseToOpen = preferredRun
            ? $evaluationRunList.find('.evaluation-run[data-run-id="' + preferredRun.run_id + '"] .evaluation-response-button').first()
            : $evaluationLists.find(".evaluation-response-button").first();
        if (currentEvaluationResponseId) {
            const $current = $evaluationLists.find(".evaluation-response-button").filter(function () {
                return Number($(this).data("responseId")) === currentEvaluationResponseId;
            }).first();
            if ($current.length) {
                $responseToOpen = $current;
                $current.closest(".run-attention-history").prop("open", true);
            }
        }
        if ($responseToOpen.length) {
            loadEvaluationResponse($responseToOpen, false);
        }
    }

    const controlledVariableLabels = {
        retrieval_method: "Retrieval method",
        top_k: "Number of retrieved sources",
        model: "Answer model",
        temperature: "Temperature",
        top_p: "Top-p",
        corpus: "Source category composition",
    };

    function selectedNewTestCategories() {
        return $newTestCategoryChoices.find("input:checked").map(function () {
            return String($(this).val());
        }).get().sort();
    }

    function setSelectedNewTestCategories(categories) {
        requestedNewTestCategories = [...new Set((categories || []).map(String))].sort();
        $newTestCategoryChoices.find("input").each(function () {
            $(this).prop("checked", requestedNewTestCategories.includes(String($(this).val())));
        });
    }

    function selectedBaselineRun() {
        const runId = Number($newTestBaselineRun.val());
        return evaluationRuns.find(function (run) {
            return Number(run.run_id) === runId;
        }) || null;
    }

    function newTestSettingsFromRun(run) {
        const configuration = run?.run_configuration_json || {};
        return {
            retrieval_method: String(run?.retrieval_method || configuration.retrieval_method || ""),
            top_k: Number(run?.top_k ?? configuration.top_k),
            model: String(run?.chat_model || configuration.answer_model || ""),
            temperature: Number(run?.temperature ?? configuration.temperature),
            top_p: Number(run?.top_p ?? configuration.top_p),
            corpus: Array.isArray(configuration.categories)
                ? configuration.categories.map(String).sort()
                : [],
        };
    }

    function questionIdsFromRun(run) {
        const configuration = run?.run_configuration_json || {};
        return Array.isArray(configuration.question_ids)
            ? configuration.question_ids.map(Number).filter(Number.isInteger)
            : [];
    }

    function currentNewTestSettings() {
        return {
            retrieval_method: String($newTestRetrieval.val() || ""),
            top_k: Number($newTestTopK.val()),
            model: String($newTestModel.val() || ""),
            temperature: Number($newTestTemperature.val()),
            top_p: Number($newTestTopP.val()),
            corpus: $newTestCorpusScope.val() === "category_subset"
                ? selectedNewTestCategories()
                : [],
        };
    }

    function controlledSettingEqual(left, right, key) {
        if (key === "corpus") {
            return JSON.stringify(left || []) === JSON.stringify(right || []);
        }
        if (["top_k", "temperature", "top_p"].includes(key)) {
            return Number(left) === Number(right);
        }
        return String(left) === String(right);
    }

    function controlledSettingDisplay(key, value) {
        if (key === "corpus") {
            return value.length ? value.map(titleCaseLabel).join(", ") : "all active documents";
        }
        if (key === "retrieval_method") {
            return retrievalDisplayName(value);
        }
        if (key === "model") {
            return modelDisplayName(value);
        }
        return String(value);
    }

    function comparisonChangeDescription() {
        const baseline = selectedBaselineRun();
        const key = String($newTestControlledVariable.val() || "");
        if (!baseline || !controlledVariableLabels[key]) {
            return "";
        }
        const before = newTestSettingsFromRun(baseline)[key];
        const after = currentNewTestSettings()[key];
        return controlledVariableLabels[key] + ": " + controlledSettingDisplay(key, before) +
            " -> " + controlledSettingDisplay(key, after);
    }

    function corpusVariantKey(categories) {
        if (!categories.length) {
            return "full_current";
        }
        return ("categories_" + categories.join("_")).slice(0, 120);
    }

    function newTestRunPayload(action) {
        const mode = String($newTestExperimentMode.val() || "standalone");
        const categories = $newTestCorpusScope.val() === "category_subset"
            ? selectedNewTestCategories()
            : [];
        const questionIds = selectedNewTestQuestionIds();
        $newTestLimit.val(String(questionIds.length));
        return {
            action: action,
            dataset_id: Number($newTestDatasetId.val()),
            name: String($newTestName.val() || "").trim(),
            limit: questionIds.length,
            question_ids: questionIds,
            model: String($newTestModel.val() || ""),
            retrieval_method: String($newTestRetrieval.val() || ""),
            top_k: Number($newTestTopK.val()),
            temperature: Number($newTestTemperature.val()),
            top_p: Number($newTestTopP.val()),
            experiment_mode: mode,
            experiment_key: mode === "standalone" ? "" : String($newTestExperimentKey.val() || "").trim(),
            baseline_run_id: mode === "comparison" ? Number($newTestBaselineRun.val()) : null,
            controlled_variable: mode === "comparison" ? String($newTestControlledVariable.val() || "") : "",
            change_from_baseline: mode === "comparison" ? comparisonChangeDescription() : "",
            corpus_variant_key: corpusVariantKey(categories),
            categories: categories,
        };
    }

    function newTestValidationError(payload) {
        if (!payload.name || !payload.dataset_id) {
            return "Give the test a name and wait for the Gold Standard to finish loading.";
        }
        const maxQuestions = Number($newTestLimit.data("max")) || 5;
        if (!Array.isArray(payload.question_ids) || payload.question_ids.length < 1 || payload.question_ids.length > maxQuestions) {
            return "Choose between 1 and " + maxQuestions + " exact reviewed questions.";
        }
        if (payload.experiment_mode !== "standalone" && !payload.experiment_key) {
            return "Give this controlled experiment a short label so its runs stay grouped.";
        }
        if ($newTestCorpusScope.val() === "category_subset" && !payload.categories.length) {
            return "Choose at least one active source category for the selected collection.";
        }
        if (payload.experiment_mode !== "comparison") {
            return "";
        }
        const baseline = selectedBaselineRun();
        if (!baseline) {
            return "Choose a completed saved test to use as the baseline.";
        }
        if (!controlledVariableLabels[payload.controlled_variable]) {
            return "Choose the one setting this comparison will change.";
        }
        const baselineQuestionIds = questionIdsFromRun(baseline);
        if (JSON.stringify(payload.question_ids) !== JSON.stringify(baselineQuestionIds)) {
            return "A controlled comparison must reuse the baseline's exact ordered reviewed-question set.";
        }
        const baselineSettings = newTestSettingsFromRun(baseline);
        const currentSettings = currentNewTestSettings();
        const differences = Object.keys(controlledVariableLabels).filter(function (key) {
            return !controlledSettingEqual(baselineSettings[key], currentSettings[key], key);
        });
        if (differences.length === 0) {
            return "Change " + controlledVariableLabels[payload.controlled_variable].toLowerCase() +
                " from the baseline before previewing.";
        }
        if (differences.length !== 1 || differences[0] !== payload.controlled_variable) {
            return "This comparison must change only " +
                controlledVariableLabels[payload.controlled_variable].toLowerCase() + ". Re-select the baseline to restore the other settings.";
        }
        return "";
    }

    function populateNewTestBaselines() {
        const selectedRunId = String($newTestBaselineRun.val() || "");
        const completedRuns = evaluationRuns.filter(function (run) {
            const questionIds = questionIdsFromRun(run);
            return run.status === "completed" && Number(run.response_count) > 0 &&
                questionIds.length === Number(run.response_count);
        });
        $newTestBaselineRun.empty().append(
            $("<option>").val("").text(completedRuns.length ? "Choose a completed test" : "No completed tests available")
        );
        completedRuns.forEach(function (run) {
            $newTestBaselineRun.append(
                $("<option>").val(run.run_id).text(
                    run.run_name + " · " + run.response_count + " answer" +
                    (Number(run.response_count) === 1 ? "" : "s") + " · " + savedTestDate(run.completed_at)
                )
            );
        });
        $newTestBaselineRun.prop("disabled", !completedRuns.length);
        if (completedRuns.some(function (run) { return String(run.run_id) === selectedRunId; })) {
            $newTestBaselineRun.val(selectedRunId);
        }
    }

    function applySelectedBaseline() {
        const baseline = selectedBaselineRun();
        if (!baseline) {
            $newTestBaselineSummary.prop("hidden", true).empty();
            return;
        }
        const settings = newTestSettingsFromRun(baseline);
        setSelectedNewTestQuestionIds(questionIdsFromRun(baseline));
        $newTestRetrieval.val(settings.retrieval_method);
        $newTestTopK.val(settings.top_k);
        $newTestModel.val(settings.model);
        $newTestTemperature.val(settings.temperature);
        $newTestTopP.val(settings.top_p);
        $newTestCorpusScope.val(settings.corpus.length ? "category_subset" : "full_current");
        setSelectedNewTestCategories(settings.corpus);
        $newTestExperimentKey.val(baseline.experiment_key || baseline.run_name);
        $newTestName.val("Comparison with " + baseline.run_name);
        renderSelectedBaselineSummary();
    }

    function renderSelectedBaselineSummary() {
        const baseline = selectedBaselineRun();
        if (!baseline) {
            $newTestBaselineSummary.prop("hidden", true).empty();
            return;
        }
        const settings = newTestSettingsFromRun(baseline);
        const questionIds = questionIdsFromRun(baseline);
        $newTestBaselineSummary.empty().append(
            $("<strong>").text("Baseline: " + baseline.run_name),
            $("<span>").text(
                questionIds.length + " exact saved question" + (questionIds.length === 1 ? "" : "s") +
                " · " + readable(settings.retrieval_method) + " · top-k " + settings.top_k +
                " · " + settings.model + " · " + controlledSettingDisplay("corpus", settings.corpus)
            )
        ).prop("hidden", false);
    }

    function syncNewTestExperimentControls(copyBaseline) {
        const mode = String($newTestExperimentMode.val() || "standalone");
        const isComparison = mode === "comparison";
        $newTestBaselineField.prop("hidden", !isComparison);
        $newTestExperimentField.prop("hidden", mode === "standalone");
        $newTestChangeField.prop("hidden", !isComparison);
        if (copyBaseline && isComparison) {
            applySelectedBaseline();
        }
        if (mode === "standalone") {
            $newTestComparisonGuide.text(
                "A standalone test is useful for a quick check. For report-ready evidence, first save a baseline and then create a comparison that changes one setting."
            );
        } else if (mode === "baseline") {
            $newTestComparisonGuide.text(
                "This test will become the reference point. Give the experiment a label; the comparison step will reuse its questions and unchanged settings."
            );
        } else {
            $newTestComparisonGuide.text(
                "Choose a baseline and one setting. The form copies and locks the other settings so the comparison stays interpretable."
            );
        }

        const $controlledInputs = $newTestRetrieval
            .add($newTestTopK)
            .add($newTestModel)
            .add($newTestTemperature)
            .add($newTestTopP)
            .add($newTestCorpusScope)
            .add($newTestQuestionIds);
        $controlledInputs.prop("disabled", false);
        $newTestCategoryChoices.find("input").prop("disabled", false);
        if (isComparison) {
            $controlledInputs.prop("disabled", true);
            const changed = String($newTestControlledVariable.val() || "");
            const controlByVariable = {
                retrieval_method: $newTestRetrieval,
                top_k: $newTestTopK,
                model: $newTestModel,
                temperature: $newTestTemperature,
                top_p: $newTestTopP,
                corpus: $newTestCorpusScope,
            };
            if (controlByVariable[changed]) {
                controlByVariable[changed].prop("disabled", false);
            }
            if (changed === "corpus") {
                $newTestCategoryChoices.find("input").prop("disabled", false);
            } else {
                $newTestCategoryChoices.find("input").prop("disabled", true);
            }
            $newTestQuestionIds.prop("disabled", true);
        }
        const showCategories = $newTestCorpusScope.val() === "category_subset";
        $newTestCategoryField.prop("hidden", !showCategories);
        if (!isComparison) {
            $newTestBaselineSummary.prop("hidden", true);
        } else {
            renderSelectedBaselineSummary();
        }
    }

    function resetNewTestRunPreview(message) {
        $createNewTestRun.prop("hidden", true).removeData("preflight");
        $newTestRunStatus.text(message || "Settings changed. Preview the test again before generating answers.");
    }

    $newTestRunToggle.on("click", function () {
        const willOpen = $newTestRunForm.prop("hidden");
        $newTestRunForm.prop("hidden", !willOpen);
        if (willOpen) {
            populateNewTestBaselines();
            syncNewTestExperimentControls(false);
            if (!$newTestName.val().trim()) {
                $newTestName.val(
                    "Test " + new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(new Date()) +
                    " · " + retrievalDisplayName($newTestRetrieval.val()) + " · " + $newTestTopK.val() + " sources"
                );
            }
            $newTestName.trigger("focus");
        }
    });

    $closeNewTestRun.on("click", function () {
        $newTestRunForm.prop("hidden", true);
        $newTestRunToggle.trigger("focus");
    });

    $newTestExperimentMode.on("change", function () {
        if ($newTestExperimentMode.val() === "comparison" && !$newTestBaselineRun.val()) {
            $newTestControlledVariable.val("");
        }
        syncNewTestExperimentControls(false);
    });

    $newTestBaselineRun.on("change", function () {
        $newTestControlledVariable.val("");
        applySelectedBaseline();
        syncNewTestExperimentControls(false);
    });

    $newTestControlledVariable.on("change", function () {
        applySelectedBaseline();
        syncNewTestExperimentControls(false);
    });

    $newTestCorpusScope.on("change", function () {
        syncNewTestExperimentControls(false);
    });

    $newTestRunForm.on("change input", "input, select", function () {
        if ($(this).hasClass("new-test-category-input")) {
            requestedNewTestCategories = [];
        }
        resetNewTestRunPreview();
    });

    $newTestRunForm.on("submit", function (event) {
        event.preventDefault();
        $previewNewTestRun.trigger("click");
    });

    $previewNewTestRun.on("click", function () {
        const payload = newTestRunPayload("preflight");
        const payloadFingerprint = JSON.stringify(payload);
        const validationError = newTestValidationError(payload);
        if (validationError) {
            $newTestRunStatus.text(validationError);
            return;
        }
        $previewNewTestRun.prop("disabled", true).text("Checking…");
        resetNewTestRunPreview("Checking model calls and estimated cost…");
        $.ajax({
            url: "api/test_runs.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify(payload),
        })
            .done(function (response) {
                if (JSON.stringify(newTestRunPayload("preflight")) !== payloadFingerprint) {
                    resetNewTestRunPreview("Settings changed while the preview was running. Preview the updated test again.");
                    return;
                }
                const plan = response.data?.preflight;
                if (!plan) {
                    $newTestRunStatus.text("The server returned an incomplete test preview.");
                    return;
                }
                const estimated = plan.estimated_cost === null
                    ? "cost unavailable"
                    : "$" + compactNumber(plan.estimated_cost, 6) + " estimated";
                const configuration = response.data?.configuration || {};
                const comparisonNote = payload.experiment_mode === "comparison"
                    ? " · one-variable comparison with " + selectedBaselineRun().run_name
                    : payload.experiment_mode === "baseline"
                        ? " · controlled baseline"
                        : "";
                $newTestRunStatus.text(
                    plan.response_count + " model call" + (Number(plan.response_count) === 1 ? "" : "s") +
                    " · " + plan.response_count + " new saved answer" + (Number(plan.response_count) === 1 ? "" : "s") +
                    " · " + (configuration.document_count || 0) + " source document" +
                    (Number(configuration.document_count) === 1 ? "" : "s") +
                    " · local 8 scored automatically · " + estimated + comparisonNote
                );
                $createNewTestRun.prop("hidden", false).data("preflight", plan);
            })
            .fail(function (xhr) {
                $newTestRunStatus.text(xhr.responseJSON?.error || "The test preview could not be completed.");
            })
            .always(function () {
                $previewNewTestRun.prop("disabled", false).text("Preview test");
            });
    });

    $createNewTestRun.on("click", function () {
        const plan = $createNewTestRun.data("preflight") || {};
        if (Number(plan.paid_call_count) > 0 && !window.confirm(
            "Generate " + plan.response_count + " new answer" + (Number(plan.response_count) === 1 ? "" : "s") +
            " using " + plan.paid_call_count + " configured model call" +
            (Number(plan.paid_call_count) === 1 ? "" : "s") + "?"
        )) {
            return;
        }
        const payload = newTestRunPayload("create");
        const validationError = newTestValidationError(payload);
        if (validationError) {
            resetNewTestRunPreview(validationError);
            return;
        }
        $createNewTestRun.prop("disabled", true).text("Generating…");
        $previewNewTestRun.prop("disabled", true);
        $newTestRunStatus.text("Generating and saving the test answers, then applying the local ten scores…");
        $.ajax({
            url: "api/test_runs.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            timeout: 310000,
            data: JSON.stringify(payload),
        })
            .done(function (response) {
                const answerCount = response.data?.responses?.length || 0;
                $newTestRunStatus.text(
                    "Test saved with " + answerCount + " answer" + (answerCount === 1 ? "" : "s") +
                    " and the local ten scores. It is now available below."
                );
                $createNewTestRun.prop("hidden", true).removeData("preflight");
                loadEvaluationDataset();
            })
            .fail(function (xhr) {
                $newTestRunStatus.text(xhr.responseJSON?.error || "The test run could not be completed.");
                $createNewTestRun.prop("hidden", false);
            })
            .always(function () {
                $createNewTestRun.prop("disabled", false).text("Generate test");
                $previewNewTestRun.prop("disabled", false);
            });
    });

    function runEvaluationPayload($panel, action) {
        const includeAdvanced = $panel.find(".run-evaluation-scope").val() === "all13";
        const payload = {
            action: action,
            run_id: Number($panel.data("runId")),
            include_advanced: includeAdvanced,
            limit: includeAdvanced ? 1 : Math.max(1, Number($panel.data("responseCount")) || 1),
            force: $panel.find(".run-evaluation-force-input").is(":checked"),
        };
        if (includeAdvanced) {
            payload.response_id = Number($panel.find(".run-evaluation-target-select").val());
        }
        return payload;
    }

    $evaluationLists.on("click", ".evaluate-run-toggle", function () {
        const $panel = $(this).siblings(".run-evaluation-panel");
        const willOpen = $panel.prop("hidden");
        $panel.prop("hidden", !willOpen);
        $(this).text(willOpen ? "Close scoring" : "Score saved answers");
    });

    $evaluationLists.on("click", ".evaluate-response-button", function () {
        const $button = $(this);
        const $run = $button.closest(".evaluation-run");
        const $panel = $run.find(".run-evaluation-panel");
        $panel.prop("hidden", false);
        $run.find(".evaluate-run-toggle").text("Close scoring");
        $panel.find(".run-evaluation-scope").val("all13");
        $panel.find(".run-evaluation-target-select").val(String($button.data("responseId")));
        $panel.find(".run-evaluation-scope").trigger("change");
        $panel.find(".preflight-run-evaluation").trigger("click");
        $panel[0].scrollIntoView({ behavior: preferredScrollBehavior(), block: "nearest" });
    });

    $evaluationLists.on("change", ".run-evaluation-scope, .run-evaluation-target-select, .run-evaluation-force-input", function () {
        const $panel = $(this).closest(".run-evaluation-panel");
        const includeAdvanced = $panel.find(".run-evaluation-scope").val() === "all13";
        $panel.find(".run-evaluation-target").prop("hidden", !includeAdvanced);
        $panel.find(".execute-run-evaluation").prop("hidden", true).removeData("preflight");
        $panel.find(".run-evaluation-status").text(
            includeAdvanced
                ? "All 15 methods will target the exact saved answer selected above. Check the plan before applying scores."
                : "The local ten will be applied to every saved answer without an external evaluator call. Check the plan first."
        );
    });

    $evaluationLists.on("click", ".preflight-run-evaluation", function () {
        const $button = $(this);
        const $panel = $button.closest(".run-evaluation-panel");
        const $status = $panel.find(".run-evaluation-status");
        $button.prop("disabled", true).text("Checking…");
        $panel.find(".execute-run-evaluation").prop("hidden", true);
        $.ajax({
            url: "api/run_evaluation.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify(runEvaluationPayload($panel, "preflight")),
        })
            .done(function (response) {
                const plan = response.data?.preflight;
                if (!plan) {
                    $status.text("The server returned an incomplete preflight.");
                    return;
                }
                const estimated = plan.estimated_cost === null
                    ? "cost unknown"
                    : "$" + compactNumber(plan.estimated_cost, 6) + " estimated";
                $status.text(
                    plan.responses + " saved answer" + (Number(plan.responses) === 1 ? "" : "s") +
                    " selected · " + plan.requested_metric_count + " methods each · " +
                    plan.application_count + " missing scores to add · " + plan.reused_count +
                    " completed scores reused · " + plan.paid_application_count +
                    " external calls · " + estimated
                );
                $panel.find(".execute-run-evaluation").prop("hidden", false).data("preflight", plan);
            })
            .fail(function (xhr) {
                $status.text(xhr.responseJSON?.error || "The evaluation preflight failed.");
            })
            .always(function () {
                $button.prop("disabled", false).text("Check what will run");
            });
    });

    $evaluationLists.on("click", ".execute-run-evaluation", function () {
        const $button = $(this);
        const $panel = $button.closest(".run-evaluation-panel");
        const plan = $button.data("preflight") || {};
        if (Number(plan.paid_application_count) > 0 && !window.confirm(
            "This will make " + plan.paid_application_count +
            " external evaluator calls using the configured API quota. Continue?"
        )) {
            return;
        }
        const $status = $panel.find(".run-evaluation-status");
        $button.prop("disabled", true).text("Applying…");
        $panel.find(".preflight-run-evaluation").prop("disabled", true);
        $status.text("Applying the selected scoring methods. Keep this page open…");
        $.ajax({
            url: "api/run_evaluation.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            timeout: 310000,
            data: JSON.stringify(runEvaluationPayload($panel, "evaluate")),
        })
            .done(function (response) {
                const outcomes = response.data?.outcomes || {};
                const items = [
                    ...(outcomes.local || []),
                    ...(outcomes.advanced || [])
                ];

                const reused = items.filter(function (item) {
                    return item.action === "reuse";
                }).length;

                const executed = items.filter(function (item) {
                    return item.result && item.action !== "reuse";
                });

                const completed = executed.filter(function (item) {
                    return item.result.status === "completed";
                }).length;

                const failed = executed.filter(function (item) {
                    return item.result.status === "failed";
                }).length;

                const skipped = executed.filter(function (item) {
                    return item.result.status === "skipped";
                }).length;

                const unknown = items.length - reused - completed - failed - skipped;
                const hasWarnings = failed > 0 || skipped > 0 || unknown > 0;

                const message = (
                    hasWarnings
                        ? "Evaluation finished with warnings: "
                        : "Evaluation completed: "
                ) +
                    completed + " new score(s) completed · " +
                    reused + " existing score(s) reused · " +
                    failed + " failed · " +
                    skipped + " skipped" +
                    (unknown ? " · " + unknown + " unknown" : "");

                $status.text("Scoring finished. Refreshing saved results…");

                loadEvaluationDataset(message, Number($panel.data("runId")));
            })
            .fail(function (xhr) {
                $status.text(xhr.responseJSON?.error || "The selected scoring request failed.");
                $button.prop("disabled", false).text("Apply scores");
                $panel.find(".preflight-run-evaluation").prop("disabled", false);
            });
    });

    function renderScoreCard(result, attempts) {
        const status = result.status || "completed";
        const passed = result.passed === null ? null : Number(result.passed) === 1;
        const cardState = status === "failed" ? "score-failed"
            : status === "skipped" ? "score-skipped"
                : passed === null ? "score-neutral" : passed ? "score-pass" : "score-review";
        const methodKey = evaluatorMethodKey(result);
        const $score = $("<article>").addClass("evaluation-score " + cardState);
        $score.append($("<span>").addClass("metric-origin metric-origin-" + methodKey).text(evaluatorMethodLabel(result)));
        const $scoreHeader = $("<div>").addClass("score-heading");
        $scoreHeader.append($("<strong>").text(result.display_name));
        $score.append($scoreHeader);
        const allRunsCompleted = Number(result.all_runs_completed_count) || 0;
        const hasAllRunsMean = result.all_runs_mean !== null && result.all_runs_mean !== undefined;
        $score.append($("<div>").addClass("score-comparison").append(
            $("<span>").append(
                $("<small>").text("This answer"),
                $("<b>").text(status === "completed" ? compactNumber(result.normalized_score) : readable(status))
            ),
            $("<span>").append(
                $("<small>").text("Completed tests"),
                $("<b>").text(hasAllRunsMean ? compactNumber(result.all_runs_mean) : "—"),
                $("<em>").text(allRunsCompleted ? "average · n=" + allRunsCompleted : "no completed scores")
            )
        ));
        $score.append($("<span>").text(
            readable(result.dimension) + " · " + readable(result.family) + " · " + (result.runtime_ms || 0) + " ms"
        ));
        $score.append($("<p>").text(result.error_message || result.explanation || "No explanation was recorded."));

        const attemptCount = Number(result.attempt_count) || 0;
        if (attemptCount > 1) {
            $score.append($("<p>").addClass("attempt-summary").text(
                attemptCount + " attempts · mean " + compactNumber(result.attempt_mean) +
                " · range " + compactNumber(result.attempt_min) + "–" + compactNumber(result.attempt_max) +
                " · σ " + compactNumber(result.attempt_stddev)
            ));
        } else {
            $score.append($("<p>").addClass("attempt-summary").text(attemptCount + " recorded attempt" + (attemptCount === 1 ? "" : "s")));
        }
        appendContract($score, result.configuration_json || {});
        const latestAttempt = attempts.length ? attempts[attempts.length - 1] : null;
        const auditConfiguration = Object.assign(
            {},
            result.configuration_json || {},
            latestAttempt?.configuration_json || {}
        );
        const $audit = $("<details>").addClass("score-audit");
        $audit.append($("<summary>").text("Run and version details"));
        const $auditList = $("<dl>");
        [
            ["Evaluator version", auditConfiguration.evaluator_version || result.version],
            ["Implementation", auditConfiguration.implementation],
            ["Framework", auditConfiguration.framework],
            ["Provider / model", [auditConfiguration.provider, auditConfiguration.model].filter(Boolean).join(" / ")],
            ["Embedding model", auditConfiguration.embedding_model],
            ["Rubric version", auditConfiguration.rubric_version],
            ["Prompt hash", auditConfiguration.prompt_hash],
            ["Attempt policy", auditConfiguration.canonical_policy],
            ["Tokens", latestAttempt?.total_tokens],
            ["Recorded cost", latestAttempt?.estimated_cost === null || latestAttempt?.estimated_cost === undefined
                ? null : "$" + compactNumber(latestAttempt.estimated_cost, 8)],
        ].forEach(function (field) {
            if (field[1] !== null && field[1] !== undefined && field[1] !== "") {
                $auditList.append($("<div>").append($("<dt>").text(field[0]), $("<dd>").text(field[1])));
            }
        });
        $audit.append($auditList);
        if (latestAttempt?.details_json && Object.keys(latestAttempt.details_json).length) {
            $audit.append($("<strong>").text("Structured result details"));
            $audit.append($("<pre>").text(JSON.stringify(latestAttempt.details_json, null, 2)));
        }
        if (latestAttempt?.raw_provider_output) {
            $audit.append($("<strong>").text("Raw provider output"));
            $audit.append($("<pre>").text(latestAttempt.raw_provider_output));
        }
        $score.append($audit);
        return $score;
    }

    function appendHumanReviewSection(data) {
        const reviews = data.human_reviews || [];
        const $section = $("<details>").addClass("human-review-section");
        const $heading = $("<summary>").addClass("human-review-heading").append(
            $("<span>").text("Human review · supporting evidence"),
            $("<strong>").text(reviews.length ? reviews.length + " current review" + (reviews.length === 1 ? "" : "s") : "No review recorded yet")
        );
        $section.append($heading);
        reviews.forEach(function (review) {
            const $review = $("<article>").addClass("human-review-card");
            $review.append($("<div>").append(
                $("<strong>").text(review.reviewer_alias),
                $("<span>").text(readable(review.overall_decision))
            ));
            const ratings = ["correctness", "completeness", "faithfulness", "relevance", "refusal_correctness"]
                .filter(function (key) { return review[key] !== null; })
                .map(function (key) { return readable(key) + " " + review[key] + "/5"; });
            $review.append($("<small>").text(ratings.length ? ratings.join(" · ") : "No numeric ratings supplied"));
            if (review.failure_category) {
                $review.append($("<p>").text("Failure category: " + readable(review.failure_category)));
            }
            if (review.notes) {
                $review.append($("<p>").text(review.notes));
            }
            $section.append($review);
        });

        const $form = $("<form>").addClass("human-review-form").attr("id", "humanReviewForm");
        $form.append($("<p>").text("Rate only dimensions you can support from the reference and retrieved evidence. Blank ratings are allowed."));
        const $identityRow = $("<div>").addClass("review-form-grid");
        $identityRow.append($("<label>").text("Reviewer name").append(
            $("<input>").addClass("form-control").attr({ name: "reviewer_alias", maxlength: 120, required: true, placeholder: "Your name or initials" })
        ));
        $identityRow.append($("<label>").text("Overall decision").append(
            $("<select>").addClass("form-select").attr({ name: "overall_decision", required: true }).append(
                $("<option>").val("").text("Choose a decision"),
                $("<option>").val("acceptable").text("Acceptable"),
                $("<option>").val("needs_revision").text("Needs revision"),
                $("<option>").val("incorrect").text("Incorrect"),
                $("<option>").val("not_applicable").text("Not applicable")
            )
        ));
        $form.append($identityRow);
        const $ratings = $("<div>").addClass("review-rating-grid");
        ["correctness", "completeness", "faithfulness", "relevance", "refusal_correctness"].forEach(function (key) {
            const $select = $("<select>").addClass("form-select").attr("name", key)
                .append($("<option>").val("").text("Not rated"));
            for (let rating = 1; rating <= 5; rating += 1) {
                $select.append($("<option>").val(rating).text(rating + (rating === 1 ? " — poor" : rating === 5 ? " — strong" : "")));
            }
            $ratings.append($("<label>").text(readable(key)).append($select));
        });
        $form.append($ratings);
        $form.append($("<label>").text("Failure category").append(
            $("<select>").addClass("form-select").attr("name", "failure_category").append(
                ["none", "retrieval_miss", "source_ranked_low", "insufficient_context", "unsupported_generation", "incomplete_answer", "incorrect_answer", "incorrect_refusal", "over_refusal", "misleading_metric", "evaluator_failure", "ambiguous_question"]
                    .map(function (value) { return $("<option>").val(value).text(readable(value)); })
            )
        ));
        $form.append($("<label>").text("Evidence-backed notes").append(
            $("<textarea>").addClass("form-control").attr({ name: "notes", rows: 3, maxlength: 5000, placeholder: "Explain the specific fact, evidence, or failure that supports this decision." })
        ));
        $form.append($("<div>").addClass("review-submit-row").append(
            $("<button>").addClass("btn btn-primary").attr("type", "submit").text("Save human review"),
            $("<span>").addClass("human-review-message").attr({ role: "status", "aria-live": "polite" })
        ));
        $section.append($form);
        $evaluationResultDetail.append($section);
    }

    function renderEvaluationDetail(data) {
        const response = data.response;
        currentEvaluationResponseId = Number(response.response_id);
        const responseContext = evaluationResponseContexts.get(currentEvaluationResponseId) || {};
        $evaluationResultDetail.empty().prop("hidden", false);
        const $header = $("<div>").addClass("response-detail-header");
        const $headerCopy = $("<div>");
        $headerCopy.append($("<span>").text(responseContext.label || "Saved answer"));
        $headerCopy.append($("<h3>").text(response.question_text));
        $header.append($headerCopy);
        $header.append($("<small>").text(responseContext.runName || response.run_name || "Saved test"));
        $evaluationResultDetail.append($header);

        const $comparison = $("<div>").addClass("answer-comparison");
        $comparison.append($("<article>").append(
            $("<span>").text("Generated answer"), $("<p>").text(response.answer_text)
        ));
        $comparison.append($("<article>").addClass("reference-answer").append(
            $("<span>").text("Reviewed reference"), $("<p>").text(response.expected_answer || "No reference answer applies.")
        ));
        $evaluationResultDetail.append($comparison);

        const $meta = $("<div>").addClass("response-meta");
        if (response.is_answerable === null ||
            response.is_answerable === undefined) {
            $meta.append(
                $("<span>").text("No Gold Standard reference")
            );
        } else {
            $meta.append(
                $("<span>").text(
                    (Number(response.is_answerable) ? "Answerable" : "Unanswerable") +
                    " test case"
                )
            );
        }
        $meta.append($("<span>").text(readable(response.retrieval_method) + " retrieval"));
        $meta.append($("<span>").text((response.latency_ms || 0) + " ms answer latency"));
        if (response.chat_model) {
            $meta.append($("<span>").text(response.chat_model));
        }
        if (response.top_k !== null && response.top_k !== undefined) {
            $meta.append($("<span>").text("Top-k: " + response.top_k));
        }
        $evaluationResultDetail.append($meta);

        const $provenance = $("<details>").addClass("response-provenance");
        $provenance.append($("<summary>").text("Run settings and technical provenance"));
        const $technicalMeta = $("<div>").addClass("response-meta");
        $technicalMeta.append($("<span>").text("Internal response ID: " + response.response_id));
        $technicalMeta.append($("<span>").text("Internal run ID: " + response.run_id));
        $technicalMeta.append($("<span>").text(
            response.total_tokens === null
                ? "Generation usage not recorded"
                : response.total_tokens + " generation tokens"
        ));
        $technicalMeta.append($("<span>").text(
            response.answer_estimated_cost === null
                ? "Generation cost unavailable"
                : "Generation cost $" + compactNumber(response.answer_estimated_cost, 8)
        ));
        $technicalMeta.append($("<span>").text("Snapshot: " + readable(response.snapshot_provenance)));
        if (response.code_version) {
            $technicalMeta.append($("<span>").text("Code: " + response.code_version));
        }
        if (response.temperature !== null && response.temperature !== undefined) {
            $technicalMeta.append($("<span>").text("Temperature: " + response.temperature));
        }
        if (response.top_p !== null && response.top_p !== undefined) {
            $technicalMeta.append($("<span>").text("Top-p: " + response.top_p));
        }
        if (response.expected_source) {
            $technicalMeta.append($("<span>").text("Expected source: " + response.expected_source));
        }
        $provenance.append($technicalMeta);
        $evaluationResultDetail.append($provenance);

        const results = data.results || [];
        const resultAttempts = data.attempts || [];
        renderEvaluationMethodSummary(data);
        [
            {
                key: "local",
                label: "Local metrics",
                emptyTitle: "No local metric results were saved.",
                emptyText: "Local metrics include deterministic checks such as Citation ID Validity and Citation Presence. These checks can evaluate saved citations without a Gold Standard reference. Other local metrics compare the answer against a reviewed reference and require Gold Standard data.",
            },
            {
                key: "judge",
                label: "LLM judge",
                emptyTitle: "The LLM judge has not evaluated this answer.",
                emptyText: "This is missing evidence, not a zero score. A guarded provider-backed evaluation can add the rubric result later.",
            },
            {
                key: "ragas",
                label: "RAGAS metrics",
                emptyTitle: "RAGAS has not evaluated this answer.",
                emptyText: "This is missing evidence, not a zero score. A guarded RAGAS run can add faithfulness, relevancy, context precision, and context recall.",
            },
            {
                key: "citation",
                label: "AI Citation Analysis",
                emptyTitle: "AI Citation Analysis has not evaluated this answer.",
                emptyText: "Citation Coverage checks whether factual claims have valid saved citations. Citation Support checks whether the cited evidence supports those claims. Both are optional, provider-backed evaluations."
            },
        ].forEach(function (method) {
            const methodResults = results.filter(function (result) {
                return evaluatorMethodKey(result) === method.key;
            });

            const catalogMethods = applicableEvaluators(
                method.key,
                response,
                results
            );

            // Hide categories with no applicable evaluators or historical results.
            if (!catalogMethods.length && !methodResults.length) {
                return;
            }

            const counts = methodStatusCounts(methodResults);
            const $section = $("<details>").addClass("score-layer-section");
            $section.append($("<summary>").addClass("score-layer-heading").append(
                $("<span>").text(method.label),
                $("<strong>").text(counts.completed + " of " + catalogMethods.length + " completed · " + counts.failed + " failed · " + counts.skipped + " skipped")
            ));
            if (methodResults.length) {
                const $scores = $("<div>").addClass("evaluation-score-list");
                methodResults.forEach(function (result) {
                    const attempts = resultAttempts.filter(function (attempt) {
                        return attempt.evaluator_key === result.evaluator_key;
                    });
                    $scores.append(renderScoreCard(result, attempts));
                });
                $section.append($scores);
            } else {
                $section.append($("<div>").addClass("layer-empty-state").append(
                    $("<strong>").text(method.emptyTitle),
                    $("<p>").text(method.emptyText)
                ));
            }
            $evaluationResultDetail.append($section);
        });

        const disagreements = data.disagreements || [];
        if (disagreements.length) {
            const $disagreement = $("<section>").addClass("disagreement-panel").append($("<strong>").text("Signals worth investigating"));
            disagreements.forEach(function (item) {
                $disagreement.append($("<article>").append($("<span>").text(item.title), $("<p>").text(item.explanation)));
            });
            $evaluationResultDetail.append($disagreement);
        }

        appendHumanReviewSection(data);

        const $contexts = $("<details>").addClass("retrieved-evidence");
        $contexts.append($("<summary>").text("Retrieved evidence (" + (data.contexts || []).length + ")"));
        (data.contexts || []).forEach(function (context) {
            const $context = $("<article>").toggleClass("expected-evidence", Boolean(context.is_expected_source));
            $context.append($("<strong>").text(
                "Rank " + context.rank_position + ": " + (context.source_path || "unknown source") +
                (context.is_expected_source ? " · expected source" : "")
            ));
            $context.append($("<p>").text(context.context_excerpt));
            const scoreParts = [];
            if (context.semantic_distance !== null) {
                scoreParts.push("semantic distance " + compactNumber(context.semantic_distance, 6));
            }
            if (context.lexical_score !== null) {
                scoreParts.push("lexical " + compactNumber(context.lexical_score, 3));
            }
            if (context.retrieval_score !== null) {
                scoreParts.push("final score " + compactNumber(context.retrieval_score, 6));
            }
            const retrievalVersion = context.retrieval_metadata_json?.version;
            if (retrievalVersion) {
                scoreParts.push("algorithm " + retrievalVersion);
            }
            $context.append($("<small>").text(scoreParts.length ? scoreParts.join(" · ") : "Retrieval score provenance unavailable"));
            $contexts.append($context);
        });
        $evaluationResultDetail.append($contexts);
    }

    function loadEvaluationResponse($button, shouldScroll) {
        $evaluationLists.find(".evaluation-response-button").removeClass("active").attr("aria-pressed", "false");
        $button.addClass("active").attr("aria-pressed", "true").prop("disabled", true);

        // Remember the selected response even when search filters
        // temporarily remove its button from the list.
        currentEvaluationResponseId = Number($button.data("responseId"));

        $.getJSON("api/evaluations.php", { response_id: $button.data("responseId") })
            .done(function (response) {
                renderEvaluationDetail(response.data);
                if (shouldScroll) {
                    $evaluationResultDetail[0].scrollIntoView({ behavior: preferredScrollBehavior(), block: "start" });
                }
            })
            .fail(function () {
                $evaluationResultDetail.empty().append(
                    $("<div>").addClass("alert alert-danger mb-0").text("The saved response could not be loaded.")
                );
            })
            .always(function () { $button.prop("disabled", false); });
    }

    $evaluationCategoryFilter.add($evaluationStatusFilter).on("change", renderEvaluationQuestions);
    $evaluationQuestionList.on("click", ".evaluation-review-button", function () {
        const $button = $(this);
        $button.prop("disabled", true);
        $.ajax({
            url: "api/evaluations.php",
            method: "PATCH",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({ question_id: $button.data("questionId"), review_status: $button.data("reviewStatus") }),
        }).done(loadEvaluationDataset).fail(function () {
            $button.prop("disabled", false);
        });
    });

    $evaluationLists.on("click", ".evaluation-response-button", function () {
        const $button = $(this);
        $button.closest(".evaluation-run").find(".run-evaluation-target-select").val($button.data("responseId"));
        loadEvaluationResponse($button, true);
    });

    // Preview citation scoring for a standalone Chat response.
    // Preflight only: does not execute evaluators or call Gemini.
    $evaluationLists.on("click", ".preview-standalone-scoring", function () {
        const $button = $(this);
        const responseId = Number($button.data("responseId"));
        const $actions = $button.closest(".standalone-response-actions");
        const $executeButton = $actions.find(".execute-standalone-scoring");

        // Invalidate any previous preview before requesting a new one.
        $executeButton
            .prop("disabled", true)
            .removeData("preflightPlan")
            .text("Run citation scoring")
            .attr("title", "Preview citation scoring before execution");
        let $details = $actions.find(".standalone-scoring-details");
        let $status;

        if (!$details.length) {
            $details = $("<details>")
                .addClass("standalone-scoring-details mt-2");

            const $summary = $("<summary>")
                .text("Citation scoring preview details");

            $status = $("<div>")
                .addClass("standalone-scoring-preview small mt-2")
                .attr({
                    role: "status",
                    "aria-live": "polite"
                });

            $details.append($summary, $status);
            $actions.append($details);
        } else {
            $status = $details.find(".standalone-scoring-preview");
        }

        // Expand automatically whenever a new preview is requested.
        $details.prop("open", true);

        $button.prop("disabled", true).text("Checking…");
        $status.empty().text("Checking citation scoring plan…");

        $.ajax({
            url: "api/evaluate_standalone.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify({
                action: "preflight",
                response_id: responseId
            })
        })
        .done(function (result) {
            if (!result.ok) {
                $status.text(result.error || "Unable to preview citation scoring.");
                return;
            }

            const plan = result.data && result.data.preflight
                ? result.data.preflight
                : {};

            const reused = Number(plan.reused_count) || 0;
            const paidCalls = Number(plan.paid_application_count) || 0;
            const estimatedCost = Number(plan.estimated_cost) || 0;
            const unknownCostCalls = Number(plan.unknown_cost_application_count) || 0;

            const costIsKnown =
                plan.estimated_cost !== null &&
                plan.estimated_cost !== undefined &&
                Number.isFinite(Number(plan.estimated_cost));

            const canExecute =
                Array.isArray(plan.applications) &&
                plan.applications.length === 2 &&
                paidCalls > 0 &&
                paidCalls <= 2 &&
                unknownCostCalls === 0 &&
                costIsKnown &&
                estimatedCost <= 0.25;

            if (canExecute) {
                $executeButton
                    .data("preflightPlan", plan)
                    .prop("disabled", false)
                    .attr("title", "Review and confirm citation scoring execution");
                }
            if (!canExecute && Array.isArray(plan.applications)) {
                const actions = plan.applications.map(function (application) {
                    return String(application.action || "").toLowerCase();
                });

                if (actions.length === 2 && actions.every(action => action === "reuse")) {
                    $executeButton
                        .text("Already scored")
                        .attr("title", "Both citation evaluations already have reusable results");
                } else if (actions.length === 2 && actions.every(action => action === "skip")) {
                    $executeButton
                        .text("No scoring needed")
                        .attr("title", "Both citation evaluators were skipped");
                }
            }
            const applications = Array.isArray(plan.applications)
                ? plan.applications
                : [];

            const evaluatorNames = {
                citation_support: "Citation Support",
                citation_coverage: "Citation Coverage"
            };

            const $breakdown = $("<div>")
                .addClass("standalone-scoring-breakdown mt-2");

            $breakdown.append(
                $("<strong>").text("Individual evaluator plan")
            );

            if (!applications.length) {
                $breakdown.append(
                    $("<div>")
                        .addClass("text-muted")
                        .text("No evaluator actions were returned.")
                );
            }

            applications.forEach(function (application) {
                const evaluatorName =
                    evaluatorNames[application.evaluator] ||
                    application.evaluator ||
                    "Unknown evaluator";

                const action = String(application.action || "unknown");
                const reason = String(application.reason || "");

                const actionLabels = {
                    reuse: "Reuse existing result",
                    run: "Run evaluator",
                    skip: "Skip evaluator"
                };

                const actionLabel = actionLabels[action] || action;

                const $item = $("<div>")
                    .addClass("standalone-scoring-evaluator mt-2");

                $item.append(
                    $("<div>").append(
                        $("<strong>").text(evaluatorName),
                        $("<span>").text(" — " + actionLabel)
                    ),
                    $("<div>")
                        .addClass("text-muted")
                        .text(reason)
                );

                $breakdown.append($item);
            });

            $status.empty().append(
                $("<strong>").text("Citation scoring preview"),
                $("<div>").text("Existing evaluations reused: " + reused),
                $("<div>").text("External evaluator calls planned: " + paidCalls),
                $("<div>").text("Estimated cost: $" + estimatedCost.toFixed(4)),
                $breakdown,
                $("<div>")
                    .addClass("text-muted mt-2")
                    .text("Preview only. No evaluations were executed.")
            );

        })
        .fail(function (xhr) {
            const message = xhr.responseJSON?.error ||
                xhr.responseJSON?.message ||
                "Unable to retrieve citation scoring preview.";

            $status.text(message);
        })
        .always(function () {
            $button.prop("disabled", false).text("Preview citation scoring");
        });
    });

// Run citation scoring only after a successful preflight and explicit confirmation.
$evaluationLists.on("click", ".execute-standalone-scoring", function () {
    const $button = $(this);
    const responseId = Number($button.data("responseId"));
    const plan = $button.data("preflightPlan");

    if (!plan || $button.prop("disabled")) {
        return;
    }

    const paidCalls = Number(plan.paid_application_count) || 0;
    const estimatedCost = Number(plan.estimated_cost);

    const validPlan =
        Array.isArray(plan.applications) &&
        plan.applications.length === 2 &&
        paidCalls > 0 &&
        paidCalls <= 2 &&
        Number(plan.unknown_cost_application_count) === 0 &&
        plan.estimated_cost !== null &&
        plan.estimated_cost !== undefined &&
        Number.isFinite(estimatedCost) &&
        estimatedCost <= 0.25;

    if (!validPlan) {
        $button.prop("disabled", true).removeData("preflightPlan");
        return;
    }

    const confirmed = window.confirm(
        "Run citation scoring for Response #" + responseId + "?\n\n" +
        "External evaluator calls planned: " + paidCalls + "\n" +
        "Estimated cost: $" + estimatedCost.toFixed(4) + "\n\n" +
        "This may make paid Gemini API calls.\n" +
        "The estimate is not a guaranteed spending cap.\n\n" +
        "Select OK to confirm or Cancel to stop."
    );

    if (!confirmed) {
        return;
    }

    const $actions = $button.closest(".standalone-response-actions");

    let $resultDetails = $actions.find(".standalone-scoring-result-details");
    let $status;

    if (!$resultDetails.length) {
        $resultDetails = $("<details>")
            .addClass("standalone-scoring-result-details mt-2");

        const $summary = $("<summary>")
            .text("Citation scoring execution results");

        $status = $("<div>")
            .addClass("standalone-scoring-result small mt-2")
            .attr({
                role: "status",
                "aria-live": "polite"
            });

        $resultDetails.append($summary, $status);
        $actions.append($resultDetails);
    } else {
        $status = $resultDetails.find(".standalone-scoring-result");
    }

    // Show the execution status automatically.
    $resultDetails.prop("open", true);
    $status.text("Submitting citation scoring request...");

    // Require a fresh preflight before any subsequent execution attempt.
    $button
        .prop("disabled", true)
        .removeData("preflightPlan")
        .text("Submitting…");

    $.ajax({
        url: "api/evaluate_standalone.php",
        method: "POST",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        data: JSON.stringify({
            action: "execute",
            response_id: responseId,
            confirm_execution: true
        })
    })
    .done(function (result) {
        if (result.ok) {
            $status.text(
                "Citation scoring request completed. Refresh evaluation results to review the scores."
            );
        } else {
            $status.text(result.error || "Citation scoring was not completed.");
        }
    })
    .fail(function (xhr) {
        const message =
            xhr.responseJSON?.error ||
            "Citation scoring request failed.";

        $status.text(message);
    })
    .always(function () {
        $button.text("Run citation scoring");
    });
});

    $evaluationResultDetail.on("submit", "#humanReviewForm", function (event) {
        event.preventDefault();
        const $form = $(this);
        const $button = $form.find('button[type="submit"]');
        const $message = $form.find(".human-review-message");
        const payload = { action: "human_review", response_id: currentEvaluationResponseId };
        $form.serializeArray().forEach(function (field) {
            payload[field.name] = field.value;
        });
        $button.prop("disabled", true);
        $message.removeClass("text-danger review-success").text("Saving evidence-backed review…");
        $.ajax({
            url: "api/evaluations.php",
            method: "POST",
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            data: JSON.stringify(payload),
        }).done(function () {
            $message.addClass("review-success").text("Review saved. Updating the evidence view…");
            loadEvaluationDataset();
        }).fail(function (xhr) {
            $message.addClass("text-danger").text(xhr.responseJSON?.error || "The review could not be saved.");
            $button.prop("disabled", false);
        });
    });

    $evaluationDatasetSelect.on("change", function () {
        loadEvaluationDataset();
    });
    loadApplicationHealth();
    loadDocuments();
    loadEvaluationDataset();
    activateWorkspaceView(window.location.hash.slice(1) || "overview", false);
});
